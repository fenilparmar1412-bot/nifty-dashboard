import { useMemo } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer,
  ReferenceArea,
} from 'recharts';
import { Strategy, PayoffPoint } from '../types';
import { generatePayoffCurve, formatCurrency } from '../utils/optionCalculations';

interface PayoffChartProps {
  strategy: Strategy;
  spotPrice: number;
}

export default function PayoffChart({ strategy, spotPrice }: PayoffChartProps) {
  const payoffData: PayoffPoint[] = useMemo(() => {
    if (strategy.legs.length === 0) {
      // Default empty chart
      const points: PayoffPoint[] = [];
      for (let i = -15; i <= 15; i++) {
        const price = spotPrice + i * 50;
        points.push({ spotPrice: price, pnl: 0 });
      }
      return points;
    }
    return generatePayoffCurve(strategy.legs, spotPrice, 0.12, 80);
  }, [strategy, spotPrice]);

  const breakEvenPoints = useMemo(() => {
    const be: number[] = [];
    if (payoffData.length < 2) return be;
    for (let i = 1; i < payoffData.length; i++) {
      if (payoffData[i - 1].pnl * payoffData[i].pnl <= 0 && payoffData[i].pnl !== 0) {
        be.push(payoffData[i].spotPrice);
      }
    }
    return be;
  }, [payoffData]);

  const minPnl = Math.min(...payoffData.map(d => d.pnl));
  const maxPnl = Math.max(...payoffData.map(d => d.pnl));
  const pnlRange = Math.max(Math.abs(minPnl), Math.abs(maxPnl), 5000);

  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: { payload: PayoffPoint }[] }) => {
    if (!active || !payload?.length) return null;
    const point = payload[0].payload;
    return (
      <div className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 shadow-xl">
        <p className="text-xs text-slate-400">Spot: <span className="text-white font-semibold tabular-nums">{point.spotPrice.toFixed(2)}</span></p>
        <p className={`text-xs font-bold tabular-nums ${point.pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
          P&L: {formatCurrency(point.pnl)}
        </p>
      </div>
    );
  };

  const profitZone = payoffData.filter(d => d.pnl > 0);
  const lossZone = payoffData.filter(d => d.pnl < 0);

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-base font-semibold text-white flex items-center gap-2">
          <svg className="w-5 h-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
          </svg>
          Payoff Diagram
        </h2>
        {strategy.legs.length > 0 && (
          <div className="flex items-center gap-3 text-xs">
            {breakEvenPoints.map((be, i) => (
              <span key={i} className="px-2 py-1 rounded-lg bg-slate-800 text-slate-300">
                BE{i + 1}: <span className="text-white font-semibold tabular-nums">{be.toFixed(2)}</span>
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={payoffData} margin={{ top: 10, right: 10, bottom: 10, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
            <XAxis
              dataKey="spotPrice"
              stroke="#64748b"
              tick={{ fontSize: 10, fill: '#64748b' }}
              tickFormatter={(v: number) => v.toFixed(0)}
              domain={['dataMin', 'dataMax']}
              type="number"
            />
            <YAxis
              stroke="#64748b"
              tick={{ fontSize: 10, fill: '#64748b' }}
              tickFormatter={(v: number) => `₹${(v / 1000).toFixed(0)}K`}
              domain={[-pnlRange, pnlRange]}
            />
            <Tooltip content={<CustomTooltip />} />

            {/* Profit zone */}
            {profitZone.length > 2 && (
              <ReferenceArea
                x1={profitZone[0].spotPrice}
                x2={profitZone[profitZone.length - 1].spotPrice}
                y1={0}
                y2={pnlRange}
                fill="rgba(16, 185, 129, 0.05)"
              />
            )}
            {/* Loss zone */}
            {lossZone.length > 2 && (
              <ReferenceArea
                x1={lossZone[0].spotPrice}
                x2={lossZone[lossZone.length - 1].spotPrice}
                y1={-pnlRange}
                y2={0}
                fill="rgba(239, 68, 68, 0.05)"
              />
            )}

            <ReferenceLine y={0} stroke="#475569" strokeWidth={1} />
            <ReferenceLine x={spotPrice} stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="5 5" label={{ value: 'SPOT', position: 'top', fill: '#f59e0b', fontSize: 10 }} />

            <Line
              type="monotone"
              dataKey="pnl"
              stroke="#818cf8"
              strokeWidth={2.5}
              dot={false}
              activeDot={{ r: 5, fill: '#818cf8', stroke: '#fff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {strategy.legs.length === 0 && (
        <p className="text-center text-slate-500 text-sm mt-2">
          Add legs in the Strategy Builder to see the payoff chart
        </p>
      )}

      {/* Strike markers */}
      {strategy.legs.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-3">
          {strategy.legs.map((leg, i) => (
            <div key={i} className="flex items-center gap-1.5 text-[11px] px-2 py-1 rounded-lg bg-slate-800/50">
              <span className={`w-2.5 h-2.5 rounded-full ${leg.type === 'CE' ? (leg.action === 'BUY' ? 'bg-amber-400' : 'bg-amber-700') : (leg.action === 'BUY' ? 'bg-emerald-400' : 'bg-emerald-700')}`} />
              <span className="text-slate-400">{leg.action} {leg.type}</span>
              <span className="text-white font-semibold">{leg.strikePrice}</span>
              <span className="text-slate-500">@ {formatCurrency(leg.premium)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
