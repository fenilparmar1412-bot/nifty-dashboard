import { useMemo, useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer,
  ReferenceArea,
} from 'recharts';
import { calculateRSI, interpretRSI } from '../utils/technicalIndicators';

interface RSIPanelProps {
  priceHistory: number[];
  symbol?: string;
}

export default function RSIPanel({ priceHistory }: RSIPanelProps) {
  const [rsiPeriod, setRsiPeriod] = useState<number>(14);

  const rsiData = useMemo(() => {
    const rsiValues = calculateRSI(priceHistory, rsiPeriod);

    // Align with price history (offset by period)
    return rsiValues.map((rsi, i) => ({
      index: i + rsiPeriod,
      rsi: Math.round(rsi * 100) / 100,
      price: priceHistory[i + rsiPeriod] || 0,
    }));
  }, [priceHistory, rsiPeriod]);

  const currentRSI = rsiData.length > 0 ? rsiData[rsiData.length - 1].rsi : 50;
  const interpretation = interpretRSI(currentRSI);

  // Also show recent RSI trend
  const rsiTrend = useMemo(() => {
    if (rsiData.length < 5) return 'NEUTRAL';
    const recent = rsiData.slice(-5);
    const first = recent[0].rsi;
    const last = recent[recent.length - 1].rsi;
    const diff = last - first;
    if (diff > 3) return 'RISING';
    if (diff < -3) return 'FALLING';
    return 'FLAT';
  }, [rsiData]);

  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: { payload: { rsi: number; price: number; index: number } }[] }) => {
    if (!active || !payload?.length) return null;
    const point = payload[0].payload;
    const interp = interpretRSI(point.rsi);
    return (
      <div className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 shadow-xl">
        <p className="text-xs text-slate-400">Price: <span className="text-white font-semibold tabular-nums">₹{point.price.toFixed(2)}</span></p>
        <p className={`text-xs font-bold ${interp.color}`}>RSI: {point.rsi.toFixed(2)}</p>
        <p className="text-[10px] text-slate-500 mt-0.5">{interp.signal}</p>
      </div>
    );
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <svg className="w-5 h-5 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
            RSI Indicator
          </h2>
          <div className="flex items-center gap-1">
            {[7, 14, 21].map(period => (
              <button
                key={period}
                onClick={() => setRsiPeriod(period)}
                className={`px-2 py-1 text-xs rounded transition-colors ${
                  rsiPeriod === period
                    ? 'bg-pink-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className={`px-3 py-1.5 rounded-lg text-xs font-bold ${interpretation.bgColor} ${interpretation.color} border border-slate-700`}>
            {interpretation.signal}
          </div>
          <div className={`text-2xl font-bold tabular-nums ${interpretation.color}`}>
            {currentRSI.toFixed(1)}
          </div>
        </div>
      </div>

      {/* RSI Chart */}
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={rsiData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />

            {/* Overbought zone */}
            <ReferenceArea y1={70} y2={100} fill="rgba(239, 68, 68, 0.08)" />
            {/* Oversold zone */}
            <ReferenceArea y1={0} y2={30} fill="rgba(16, 185, 129, 0.08)" />

            <XAxis dataKey="index" hide />
            <YAxis
              domain={[0, 100]}
              ticks={[20, 30, 50, 70, 80]}
              stroke="#64748b"
              tick={{ fontSize: 10, fill: '#64748b' }}
            />
            <Tooltip content={<CustomTooltip />} />

            <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'Overbought', position: 'right', fill: '#ef4444', fontSize: 10 }} />
            <ReferenceLine y={50} stroke="#64748b" strokeDasharray="2 2" />
            <ReferenceLine y={30} stroke="#10b981" strokeDasharray="4 4" label={{ value: 'Oversold', position: 'right', fill: '#10b981', fontSize: 10 }} />

            <Line
              type="monotone"
              dataKey="rsi"
              stroke="#ec4899"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4, fill: '#ec4899', stroke: '#fff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Interpretation */}
      <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
        <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-lg p-2">
          <p className="text-emerald-400 font-semibold">RSI &lt; 30</p>
          <p className="text-slate-400 text-[10px] mt-0.5">Oversold — Buy zone</p>
        </div>
        <div className="bg-slate-700/30 border border-slate-700 rounded-lg p-2">
          <p className="text-slate-300 font-semibold">RSI 30-70</p>
          <p className="text-slate-400 text-[10px] mt-0.5">Neutral — Hold</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/25 rounded-lg p-2">
          <p className="text-red-400 font-semibold">RSI &gt; 70</p>
          <p className="text-slate-400 text-[10px] mt-0.5">Overbought — Sell zone</p>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between text-xs">
        <span className="text-slate-500">
          Trend: <span className={`font-semibold ${
            rsiTrend === 'RISING' ? 'text-emerald-400' :
            rsiTrend === 'FALLING' ? 'text-red-400' :
            'text-slate-300'
          }`}>
            {rsiTrend === 'RISING' ? '↑ Rising' : rsiTrend === 'FALLING' ? '↓ Falling' : '→ Flat'}
          </span>
        </span>
        <span className="text-slate-500">
          {interpretation.message}
        </span>
      </div>
    </div>
  );
}
