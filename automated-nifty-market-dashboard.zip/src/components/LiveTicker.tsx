import { NiftyIndex } from '../types';
import { formatCurrency } from '../utils/optionCalculations';
import { MarketStatus } from '../utils/marketHours';

interface LiveTickerProps {
  index: NiftyIndex | null;
  lastUpdated: Date | null;
  loading: boolean;
  marketStatus: MarketStatus;
  dataSource?: 'YAHOO' | 'NSE' | 'SIMULATED';
  onRefresh: () => void;
}

export default function LiveTicker({ index, lastUpdated, loading, marketStatus, dataSource, onRefresh }: LiveTickerProps) {
  const isPositive = index && index.change >= 0;
  const isMarketOpen = marketStatus.isOpen;

  return (
    <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700/50 relative overflow-hidden">
      {/* Market Closed Overlay Banner */}
      {!isMarketOpen && !loading && (
        <div className="absolute inset-0 bg-gradient-to-r from-red-900/20 via-orange-900/20 to-red-900/20 pointer-events-none" />
      )}

      <div className="max-w-[1600px] mx-auto px-4 py-3 relative">
        {/* Market Status Banner (when closed) */}
        {!isMarketOpen && !loading && (
          <div className="mb-2 px-4 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-amber-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-xs text-amber-300 font-semibold">
                {marketStatus.label}
              </span>
              {marketStatus.nextOpen && (
                <span className="text-xs text-slate-400">
                  — Next open: <span className="text-white font-medium">{marketStatus.nextOpen}</span>
                </span>
              )}
            </div>
            <span className="text-[10px] text-amber-400/80 font-medium">
              📊 Showing last session data (frozen)
            </span>
          </div>
        )}

        <div className="flex items-center justify-between flex-wrap gap-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold text-white tracking-tight">NIFTY OPTIONS</h1>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest">Live Dashboard</p>
              </div>
            </div>
          </div>

          {/* Nifty Index */}
          {loading ? (
            <div className="flex items-center gap-2 text-slate-400">
              <div className="animate-spin w-4 h-4 border-2 border-amber-500 border-t-transparent rounded-full" />
              <span className="text-sm">Connecting...</span>
            </div>
          ) : index ? (
            <div className="flex items-center gap-5 flex-wrap">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">NIFTY 50</span>
                <span className="text-2xl font-bold text-white tabular-nums tracking-tight">
                  {index.spotPrice.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <div className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-semibold ${
                  isPositive ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25' : 'bg-red-500/15 text-red-400 border border-red-500/25'
                }`}>
                  <span>{isPositive ? '▲' : '▼'}</span>
                  <span className="tabular-nums">{Math.abs(index.change).toFixed(2)}</span>
                  <span className="tabular-nums">({isPositive ? '+' : ''}{index.changePercent.toFixed(2)}%)</span>
                </div>
                {!isMarketOpen && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-700/50 text-slate-400 border border-slate-600/50">
                    LAST CLOSE
                  </span>
                )}
              </div>

              {/* Day Range */}
              <div className="hidden md:flex items-center gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">H</span>
                  <span className="text-slate-300 font-mono tabular-nums">{formatCurrency(index.dayHigh)}</span>
                </div>
                <div className="w-20 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-500 via-amber-400 to-emerald-500 rounded-full"
                    style={{
                      width: `${Math.min(100, Math.max(0, ((index.spotPrice - index.dayLow) / Math.max(0.01, index.dayHigh - index.dayLow)) * 100))}%`,
                    }}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">L</span>
                  <span className="text-slate-300 font-mono tabular-nums">{formatCurrency(index.dayLow)}</span>
                </div>
              </div>
            </div>
          ) : null}

          {/* Right side */}
          <div className="flex items-center gap-3">
            {lastUpdated && (
              <span className="text-[11px] text-slate-500 tabular-nums">
                {isMarketOpen ? 'Updated' : 'Frozen at'}: {lastUpdated.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            )}
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${
                loading ? 'bg-amber-500 animate-pulse' :
                isMarketOpen ? 'bg-emerald-500' :
                'bg-slate-500'
              } shadow-sm`} />
              <span className="text-[11px] text-slate-500">
                {loading ? 'Fetching' : isMarketOpen ? 'Live' : 'Closed'}
              </span>
              {dataSource && !loading && (
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                  dataSource === 'YAHOO' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' :
                  dataSource === 'NSE' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' :
                  'bg-slate-700/50 text-slate-400 border border-slate-600'
                }`} title={dataSource === 'YAHOO' ? 'Live data from Yahoo Finance' : dataSource === 'NSE' ? 'Live data from NSE India' : 'Simulated data — market closed'}>
                  {dataSource === 'YAHOO' ? '● LIVE YAHOO' : dataSource === 'NSE' ? '● LIVE NSE' : '○ SIMULATED'}
                </span>
              )}
            </div>
            <button
              onClick={onRefresh}
              className="p-2 rounded-lg bg-slate-700/50 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
              title="Refresh"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
