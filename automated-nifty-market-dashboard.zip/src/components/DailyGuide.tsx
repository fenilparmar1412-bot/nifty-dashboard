import { useState, useEffect } from 'react';

export default function DailyGuide() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'workflow' | 'sheets' | 'shortcuts'>('workflow');

  // Get current market status
  const getMarketStatus = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const totalMinutes = hours * 60 + minutes;
    const day = now.getDay();

    // Weekend check
    if (day === 0 || day === 6) {
      return { status: 'CLOSED', label: 'Market Closed (Weekend)', color: 'bg-slate-500' };
    }

    // Pre-market: 9:00 - 9:08
    if (totalMinutes >= 540 && totalMinutes < 548) {
      return { status: 'PRE-OPEN', label: 'Pre-Open Session', color: 'bg-amber-500 animate-pulse' };
    }
    // Regular market: 9:15 - 15:30
    if (totalMinutes >= 555 && totalMinutes < 930) {
      return { status: 'LIVE', label: 'Market Open', color: 'bg-emerald-500 animate-pulse' };
    }
    // Post-market: 15:30 - 16:00
    if (totalMinutes >= 930 && totalMinutes < 960) {
      return { status: 'POST', label: 'Post-Market', color: 'bg-amber-500' };
    }
    return { status: 'CLOSED', label: 'Market Closed', color: 'bg-slate-500' };
  };

  const [marketStatus, setMarketStatus] = useState(getMarketStatus());

  useEffect(() => {
    const interval = setInterval(() => setMarketStatus(getMarketStatus()), 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Floating Market Status */}
      <div className="fixed bottom-4 left-4 z-40">
        <div className={`px-3 py-2 rounded-xl backdrop-blur-md border flex items-center gap-2 ${
          marketStatus.status === 'LIVE'
            ? 'bg-emerald-900/80 border-emerald-500/50 shadow-lg shadow-emerald-500/20'
            : 'bg-slate-800/80 border-slate-700/50'
        }`}>
          <span className={`w-2 h-2 rounded-full ${marketStatus.color}`} />
          <span className="text-xs font-semibold text-white">{marketStatus.label}</span>
        </div>
      </div>

      {/* Floating Help Button */}
      <button
        onClick={() => setIsOpen(true)}
        aria-label="help"
        title="Daily Guide — અહીં click કરો"
        className="fixed bottom-4 right-4 z-40 w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg shadow-indigo-500/30 flex items-center justify-center hover:scale-110 transition-transform"
      >
        <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>

      {/* Guide Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setIsOpen(false)}>
          <div
            className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full max-h-[85vh] overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-700 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">📚 Daily Trading Guide</h2>
                <p className="text-xs text-slate-400 mt-0.5">આ dashboard daily કેવી રીતે use કરવું</p>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Tabs */}
            <div className="px-6 pt-4 flex gap-2 border-b border-slate-800">
              {[
                { id: 'workflow', label: '📅 Daily Workflow', desc: 'રોજનું કામ' },
                { id: 'sheets', label: '📊 Google Sheets', desc: 'Sheets integration' },
                { id: 'shortcuts', label: '⌨️ Tips & Tricks', desc: 'Pro tips' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`px-4 py-2.5 text-sm font-semibold rounded-t-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-slate-800 text-white border-b-2 border-indigo-500'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="px-6 py-5 overflow-y-auto flex-1">
              {activeTab === 'workflow' && (
                <div className="space-y-4">
                  <div className="bg-indigo-500/10 border border-indigo-500/25 rounded-xl p-4">
                    <p className="text-sm text-indigo-300 font-semibold mb-1">💡 NSE API Note</p>
                    <p className="text-xs text-slate-300">
                      Browser CORS restrictions ના કારણે NSE data directly browser માં નહીં આવે. Dashboard realistic simulation use કરે છે. Real data માટે backend server જોઈએ (see Google Sheets tab).
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-amber-400">🕘 9:00 AM - Pre-Market Check</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>✅ <span className="text-white">Live Ticker</span> પર Nifty spot price check કરો</p>
                      <p>✅ <span className="text-white">Day Range</span> bar જુઓ — bullish કે bearish?</p>
                      <p>✅ Gap up/down કેટલું છે note કરો</p>
                    </div>

                    <h3 className="text-sm font-bold text-amber-400 mt-4">🕤 9:15 AM - Market Opens</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>✅ <span className="text-white">Option Chain</span> માં OI (Open Interest) જુઓ — કયાં strikes પર maximum OI છે (support/resistance)</p>
                      <p>✅ <span className="text-white">IV</span> column check કરો — high IV = મોંઘા premiums</p>
                      <p>✅ Change in OI જુઓ — fresh positions add થાય છે કે close થાય છે</p>
                    </div>

                    <h3 className="text-sm font-bold text-amber-400 mt-4">🎯 Strategy Selection</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>📈 <span className="text-emerald-400 font-semibold">Bullish View</span> → Bullish Call / Bull Call Spread</p>
                      <p>📉 <span className="text-red-400 font-semibold">Bearish View</span> → Bearish Put</p>
                      <p>↔️ <span className="text-slate-300 font-semibold">Range-bound</span> → Iron Condor / Short Straddle</p>
                      <p>🚀 <span className="text-amber-400 font-semibold">High Volatility Expected</span> → Long Straddle / Strangle</p>
                    </div>

                    <h3 className="text-sm font-bold text-amber-400 mt-4">🛠️ Strategy Setup</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>1️⃣ Strategy Builder માં preset પસંદ કરો અથવા manual legs add કરો</p>
                      <p>2️⃣ <span className="text-white">Payoff Chart</span> જુઓ — break-even points note કરો</p>
                      <p>3️⃣ <span className="text-white">Max Profit / Max Loss</span> check કરો — risk comfortable છે?</p>
                      <p>4️⃣ <span className="text-white">Greeks Panel</span> માં Delta જુઓ — directional exposure</p>
                    </div>

                    <h3 className="text-sm font-bold text-amber-400 mt-4">💰 Before Placing Trade</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>✅ Premium Calculator માં actual premium verify કરો (bid-ask spread)</p>
                      <p>✅ Position size check — capital ના 2% થી વધુ risk ન લો</p>
                      <p>✅ Stop-loss mental note કરો (max loss)</p>
                      <p>✅ Expiry date confirm કરો — weekly vs monthly</p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'sheets' && (
                <div className="space-y-4">
                  <div className="bg-amber-500/10 border border-amber-500/25 rounded-xl p-4">
                    <p className="text-sm text-amber-300 font-semibold mb-1">📊 Google Sheets Integration</p>
                    <p className="text-xs text-slate-300">
                      Google Sheets માં live Nifty data લાવવા અને dashboard link કરવા માટે:
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-sm font-bold text-indigo-400">Step 1: NSE Data to Google Sheets</h3>
                    <div className="bg-slate-800/50 rounded-lg p-4 text-xs text-slate-300 space-y-2">
                      <p className="text-slate-400">Google Sheets ને Apps Script editor ખોલો અને આ code paste કરો:</p>
                      <pre className="bg-slate-900 border border-slate-700 rounded p-3 overflow-x-auto text-[11px] text-emerald-400 font-mono">{`function fetchNiftyData() {
  const url = "https://www.nseindia.com/api/option-chain-indices?symbol=NIFTY";
  const options = {
    "method": "get",
    "headers": {
      "User-Agent": "Mozilla/5.0",
      "Accept": "application/json"
    },
    "muteHttpExceptions": true
  };

  // NSE requires cookies first - use this workaround:
  const cookieUrl = "https://www.nseindia.com";
  UrlFetchApp.fetch(cookieUrl, options);

  const response = UrlFetchApp.fetch(url, options);
  const data = JSON.parse(response.getContentText());

  const sheet = SpreadsheetApp.getActiveSheet();
  const spot = data.records.underlyingValue;

  // Write to sheet
  sheet.getRange("A1").setValue("Spot Price");
  sheet.getRange("B1").setValue(spot);

  // Write option chain from row 3
  const rows = data.records.data;
  rows.forEach((r, i) => {
    sheet.getRange(i + 3, 1).setValue(r.CE?.strikePrice);
    sheet.getRange(i + 3, 2).setValue(r.CE?.lastPrice);
    sheet.getRange(i + 3, 3).setValue(r.CE?.openInterest);
    sheet.getRange(i + 3, 4).setValue(r.PE?.lastPrice);
    sheet.getRange(i + 3, 5).setValue(r.PE?.openInterest);
  });
}`}</pre>
                    </div>

                    <h3 className="text-sm font-bold text-indigo-400">Step 2: Auto-Refresh Trigger</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>1. Apps Script માં <span className="text-amber-400">Triggers (⏰ icon)</span> click કરો</p>
                      <p>2. <span className="text-amber-400">"+ Add Trigger"</span> → function: fetchNiftyData</p>
                      <p>3. Event: <span className="text-amber-400">Time-driven</span> → Minutes timer → Every minute</p>
                      <p>4. Save — હવે sheets auto-update થશે!</p>
                    </div>

                    <h3 className="text-sm font-bold text-indigo-400">Step 3: Use Sheet Data in Dashboard</h3>
                    <div className="bg-slate-800/50 rounded-lg p-3 text-sm text-slate-300 space-y-1.5">
                      <p>1. Google Sheets → File → <span className="text-amber-400">Share</span> → Anyone with link</p>
                      <p>2. Publish as CSV: File → Share → Publish to web</p>
                      <p>3. CSV URL copy કરો</p>
                      <p>4. Dashboard માં `useNiftyData.ts` file update કરો CSV read કરવા માટે</p>
                    </div>

                    <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-xl p-4 mt-4">
                      <p className="text-sm text-emerald-300 font-semibold mb-1">✅ Easier Alternative</p>
                      <p className="text-xs text-slate-300">
                        Google Sheets add-ons like <span className="text-white font-semibold">"NSE Stock Data"</span> અથવા <span className="text-white font-semibold">"Marketstack"</span> use કરો — no coding!
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'shortcuts' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold text-indigo-400">⚡ Quick Tips</h3>
                  <div className="space-y-2">
                    {[
                      { icon: '🔄', title: 'Auto-Refresh', desc: 'Data every 3 seconds auto-update થાય છે — refresh button manual માટે' },
                      { icon: '🎯', title: 'Strike Selection', desc: 'Option chain માં CE+/PE+ buttons click કરો — strategy માં auto-add થશે' },
                      { icon: '📊', title: 'ATM Highlight', desc: 'ATM strike yellow color માં highlight થાય છે' },
                      { icon: '🎨', title: 'Color Codes', desc: 'Green = positive, Red = negative, Amber = CE, Emerald = PE' },
                      { icon: '💹', title: 'OI Bars', desc: 'Option chain માં horizontal bars = OI volume visualization' },
                      { icon: '🎛️', title: 'Filters', desc: 'ATM/ITM/OTM filter buttons use કરો chain filter કરવા માટે' },
                      { icon: '📐', title: 'Greeks Inputs', desc: 'IV અને days-to-expiry change કરી ને impact જુઓ live' },
                      { icon: '💾', title: 'Lot Size', desc: 'Nifty lot size = 50 (default) — strategy માં quantity update કરી શકો' },
                    ].map((tip, i) => (
                      <div key={i} className="bg-slate-800/50 rounded-lg p-3 flex items-start gap-3">
                        <span className="text-2xl">{tip.icon}</span>
                        <div>
                          <p className="text-sm font-semibold text-white">{tip.title}</p>
                          <p className="text-xs text-slate-400 mt-0.5">{tip.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border border-indigo-500/25 rounded-xl">
                    <h4 className="text-sm font-bold text-white mb-2">🚀 Daily Use Checklist</h4>
                    <ol className="space-y-1.5 text-xs text-slate-300 list-decimal list-inside">
                      <li>Dashboard ખોલો (bookmark કરી લો)</li>
                      <li>Live ticker પર spot price + change% check કરો</li>
                      <li>Option chain filter → ATM view</li>
                      <li>High OI strikes identify કરો (support/resistance)</li>
                      <li>Strategy preset select કરો based on view</li>
                      <li>Payoff chart પર break-even + max loss confirm કરો</li>
                      <li>Greeks (esp. Delta + Theta) review કરો</li>
                      <li>Premium calculator માં final premium verify</li>
                      <li>Broker platform પર જાઓ → trade place કરો</li>
                    </ol>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
