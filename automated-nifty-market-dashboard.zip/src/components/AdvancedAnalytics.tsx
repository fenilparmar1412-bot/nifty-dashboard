import { useMemo, useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { OptionData } from '../types';
import {
  calculateIVRank,
  interpretIV,
  calculateExpectedMove,
  calculateImpliedMoveFromStraddle,
  projectThetaDecay,
  calculateRiskReward,
  calculateKellyPosition,
  calculateFixedRiskPosition,
  calculateIVSkew,
  calculateStraddleBreakeven,
  calculateProbabilityITM,
  calculatePOP,
} from '../utils/advancedFormulas';
import { formatCurrency, calculateTotalStrategyGreeks } from '../utils/optionCalculations';

interface AdvancedAnalyticsProps {
  optionChain: OptionData[];
  spotPrice: number;
  lotSize?: number;
  strategyLegs: { type: 'CE' | 'PE'; action: 'BUY' | 'SELL'; strikePrice: number; premium: number; quantity: number }[];
}

export default function AdvancedAnalytics({ optionChain, spotPrice, strategyLegs }: AdvancedAnalyticsProps) {
  const [userCapital, setUserCapital] = useState<number>(500000);
  const [winRate, setWinRate] = useState<number>(55);

  // Find ATM and OTM strikes
  const atmRow = useMemo(() => {
    if (optionChain.length === 0) return null;
    return optionChain.reduce((prev, curr) =>
      Math.abs(curr.strikePrice - spotPrice) < Math.abs(prev.strikePrice - spotPrice) ? curr : prev
    );
  }, [optionChain, spotPrice]);

  const otmPutRow = useMemo(() => {
    if (!atmRow) return null;
    const targetStrike = atmRow.strikePrice - (optionChain.length > 1 ? Math.abs(optionChain[1].strikePrice - optionChain[0].strikePrice) * 2 : 100);
    return optionChain.reduce((prev, curr) =>
      Math.abs(curr.strikePrice - targetStrike) < Math.abs(prev.strikePrice - targetStrike) ? curr : prev
    );
  }, [optionChain, atmRow]);

  const otmCallRow = useMemo(() => {
    if (!atmRow) return null;
    const targetStrike = atmRow.strikePrice + (optionChain.length > 1 ? Math.abs(optionChain[1].strikePrice - optionChain[0].strikePrice) * 2 : 100);
    return optionChain.reduce((prev, curr) =>
      Math.abs(curr.strikePrice - targetStrike) < Math.abs(prev.strikePrice - targetStrike) ? curr : prev
    );
  }, [optionChain, atmRow]);

  const currentIV = atmRow ? (atmRow.ce.impliedVolatility + atmRow.pe.impliedVolatility) / 2 : 15;

  // 1. IV Analysis
  const ivAnalysis = useMemo(() => {
    const iv52wLow = currentIV * 0.6;
    const iv52wHigh = currentIV * 1.5;
    const ivRank = calculateIVRank(currentIV, iv52wLow, iv52wHigh);
    const interpretation = interpretIV(ivRank);
    return { ivRank, iv52wLow, iv52wHigh, interpretation };
  }, [currentIV]);

  // 2. Expected Move
  const expectedMove = useMemo(() => {
    return calculateExpectedMove(spotPrice, currentIV, 7);
  }, [spotPrice, currentIV]);

  // 3. Implied Move from Straddle
  const impliedMove = useMemo(() => {
    if (!atmRow) return 0;
    return calculateImpliedMoveFromStraddle(atmRow.ce.lastPrice, atmRow.pe.lastPrice, spotPrice);
  }, [atmRow, spotPrice]);

  // 4. IV Skew
  const ivSkew = useMemo(() => {
    if (!atmRow || !otmPutRow || !otmCallRow) {
      return { skew: 0, putSkew: 0, callSkew: 0, interpretation: '', signal: 'NEUTRAL', color: 'text-slate-400' };
    }
    return calculateIVSkew(
      currentIV,
      (otmPutRow.ce.impliedVolatility + otmPutRow.pe.impliedVolatility) / 2,
      (otmCallRow.ce.impliedVolatility + otmCallRow.pe.impliedVolatility) / 2
    );
  }, [atmRow, otmPutRow, otmCallRow, currentIV]);

  // 5. Theta Decay Projection
  const thetaData = useMemo(() => {
    if (!atmRow) return [];
    return projectThetaDecay(
      spotPrice,
      atmRow.strikePrice,
      currentIV,
      7,
      0.07,
      'CE'
    );
  }, [spotPrice, atmRow, currentIV]);

  // 6. Strategy Max Profit/Loss
  const strategyStats = useMemo(() => {
    if (strategyLegs.length === 0) return { maxProfit: 0, maxLoss: 0 };

    let maxProfit = -Infinity;
    let maxLoss = Infinity;

    for (let price = spotPrice * 0.8; price <= spotPrice * 1.2; price += 10) {
      let pnl = 0;
      strategyLegs.forEach(leg => {
        let iv = 0;
        if (leg.type === 'CE') iv = Math.max(0, price - leg.strikePrice);
        else iv = Math.max(0, leg.strikePrice - price);
        pnl += (iv - leg.premium) * leg.quantity * (leg.action === 'BUY' ? 1 : -1);
      });
      if (pnl > maxProfit) maxProfit = pnl;
      if (pnl < maxLoss) maxLoss = pnl;
    }

    return { maxProfit, maxLoss };
  }, [strategyLegs, spotPrice]);

  const riskReward = useMemo(() => {
    return calculateRiskReward(strategyStats.maxProfit, strategyStats.maxLoss);
  }, [strategyStats]);

  // 7. Position Sizing
  const kelly = useMemo(() => {
    return calculateKellyPosition(winRate, Math.abs(strategyStats.maxProfit), Math.abs(strategyStats.maxLoss), userCapital);
  }, [winRate, strategyStats, userCapital]);

  const fixedRisk = useMemo(() => {
    return calculateFixedRiskPosition(userCapital, 2, Math.abs(strategyStats.maxLoss));
  }, [userCapital, strategyStats]);

  // 8. Straddle Analysis
  const straddleAnalysis = useMemo(() => {
    if (!atmRow) return null;
    return calculateStraddleBreakeven(
      atmRow.strikePrice,
      atmRow.ce.lastPrice,
      atmRow.pe.lastPrice
    );
  }, [atmRow]);

  // 9. ATM Probability ITM
  const probabilityITM = useMemo(() => {
    if (!atmRow) return { ce: 0, pe: 0 };
    return {
      ce: calculateProbabilityITM(spotPrice, atmRow.strikePrice, 7 / 365, currentIV, 'CE'),
      pe: calculateProbabilityITM(spotPrice, atmRow.strikePrice, 7 / 365, currentIV, 'PE'),
    };
  }, [spotPrice, atmRow, currentIV]);

  // 10. POP for ATM Call Buy
  const popATMCall = useMemo(() => {
    if (!atmRow) return 0;
    return calculatePOP(spotPrice, atmRow.strikePrice, atmRow.ce.lastPrice, 7 / 365, currentIV, 'CE', 'BUY');
  }, [spotPrice, atmRow, currentIV]);

  // Strategy Delta
  const strategyDelta = useMemo(() => {
    if (strategyLegs.length === 0) return 0;
    const greeks = calculateTotalStrategyGreeks(
      strategyLegs.map(l => ({ type: l.type, action: l.action, strikePrice: l.strikePrice })),
      spotPrice,
      7 / 365,
      currentIV / 100,
      0.07
    );
    return greeks.delta;
  }, [strategyLegs, spotPrice, currentIV]);

  const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: { payload: { day: number; price: number; theta: number } }[] }) => {
    if (!active || !payload?.length) return null;
    const p = payload[0].payload;
    return (
      <div className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 shadow-xl">
        <p className="text-xs text-slate-400">Day: <span className="text-white font-semibold">{p.day}</span></p>
        <p className="text-xs text-amber-400 font-bold tabular-nums">{formatCurrency(p.price)}</p>
        <p className="text-[10px] text-red-400 tabular-nums">Theta: -{formatCurrency(p.theta)}</p>
      </div>
    );
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-base font-semibold text-white flex items-center gap-2">
          <svg className="w-5 h-5 text-fuchsia-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
          Advanced Analytics & Formulas
          <span className="text-[10px] text-fuchsia-400 font-normal ml-2">12 Pro Formulas</span>
        </h2>
      </div>

      {/* Row 1: IV + Expected Move + Skew */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-5">
        {/* IV Rank */}
        <div className="bg-gradient-to-br from-purple-500/10 to-fuchsia-500/10 border border-purple-500/25 rounded-xl p-4">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">IV Rank & Analysis</p>
          <div className="flex items-end justify-between mb-2">
            <span className={`text-3xl font-bold tabular-nums ${ivAnalysis.interpretation.color}`}>
              {ivAnalysis.ivRank.toFixed(0)}%
            </span>
            <span className={`text-xs font-bold ${ivAnalysis.interpretation.color}`}>
              {ivAnalysis.interpretation.signal}
            </span>
          </div>
          <div className="h-2 bg-slate-800 rounded-full overflow-hidden mb-2">
            <div
              className={`h-full transition-all ${
                ivAnalysis.ivRank >= 80 ? 'bg-red-500' :
                ivAnalysis.ivRank >= 60 ? 'bg-orange-500' :
                ivAnalysis.ivRank >= 40 ? 'bg-amber-500' :
                ivAnalysis.ivRank >= 20 ? 'bg-cyan-500' :
                'bg-emerald-500'
              }`}
              style={{ width: `${ivAnalysis.ivRank}%` }}
            />
          </div>
          <p className="text-[10px] text-slate-400 mb-1">{ivAnalysis.interpretation.message}</p>
          <p className="text-[10px] font-semibold text-white">→ {ivAnalysis.interpretation.strategy}</p>
          <div className="mt-2 flex justify-between text-[9px] text-slate-500">
            <span>IV: {currentIV.toFixed(1)}%</span>
            <span>Range: {ivAnalysis.iv52wLow.toFixed(1)}% - {ivAnalysis.iv52wHigh.toFixed(1)}%</span>
          </div>
        </div>

        {/* Expected Move */}
        <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/25 rounded-xl p-4">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">Expected Move (7 days)</p>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">1σ (68% prob)</span>
              <span className="text-cyan-400 font-bold tabular-nums">±{expectedMove.sigma1.range.toFixed(0)} pts</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">2σ (95% prob)</span>
              <span className="text-blue-400 font-bold tabular-nums">±{expectedMove.sigma2.range.toFixed(0)} pts</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">3σ (99.7%)</span>
              <span className="text-indigo-400 font-bold tabular-nums">±{expectedMove.sigma3.range.toFixed(0)} pts</span>
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-700 space-y-1 text-[10px]">
            <div className="flex justify-between">
              <span className="text-slate-400">Upper 1σ:</span>
              <span className="text-emerald-400 font-semibold tabular-nums">{expectedMove.sigma1.up.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Lower 1σ:</span>
              <span className="text-red-400 font-semibold tabular-nums">{expectedMove.sigma1.down.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Daily move:</span>
              <span className="text-white font-semibold tabular-nums">±{expectedMove.dailyMove.toFixed(0)}</span>
            </div>
          </div>
        </div>

        {/* IV Skew */}
        <div className="bg-gradient-to-br from-pink-500/10 to-rose-500/10 border border-pink-500/25 rounded-xl p-4">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">IV Skew Analysis</p>
          <div className="flex items-end justify-between mb-2">
            <span className={`text-3xl font-bold tabular-nums ${ivSkew.color}`}>
              {ivSkew.skew > 0 ? '+' : ''}{ivSkew.skew.toFixed(2)}
            </span>
            <span className={`text-xs font-bold ${ivSkew.color}`}>
              {ivSkew.signal}
            </span>
          </div>
          <div className="space-y-1 text-[10px]">
            <div className="flex justify-between">
              <span className="text-slate-400">Put Skew:</span>
              <span className={`font-semibold tabular-nums ${ivSkew.putSkew >= 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {ivSkew.putSkew > 0 ? '+' : ''}{ivSkew.putSkew.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Call Skew:</span>
              <span className={`font-semibold tabular-nums ${ivSkew.callSkew >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {ivSkew.callSkew > 0 ? '+' : ''}{ivSkew.callSkew.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Implied Move:</span>
              <span className="text-amber-400 font-semibold tabular-nums">±{impliedMove.toFixed(2)}%</span>
            </div>
          </div>
          <p className="text-[10px] text-slate-400 mt-2">{ivSkew.interpretation}</p>
        </div>
      </div>

      {/* Row 2: Theta Decay Chart + Probabilities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mb-5">
        {/* Theta Decay Chart */}
        <div className="lg:col-span-2 bg-slate-800/40 border border-slate-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xs font-semibold text-white">📉 Theta Decay Projection (ATM Call)</p>
              <p className="text-[10px] text-slate-500">How premium erodes as expiry approaches</p>
            </div>
            {thetaData.length > 0 && (
              <div className="text-right">
                <p className="text-xs text-slate-400">Total decay</p>
                <p className="text-sm font-bold text-red-400 tabular-nums">
                  -{formatCurrency(thetaData[0].price - thetaData[thetaData.length - 1].price)}
                </p>
              </div>
            )}
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={thetaData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.1)" />
                <XAxis
                  dataKey="day"
                  stroke="#64748b"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  label={{ value: 'Days', position: 'bottom', fill: '#64748b', fontSize: 10, offset: -5 }}
                />
                <YAxis
                  stroke="#64748b"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(v: number) => `₹${v.toFixed(0)}`}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine x={0} stroke="#64748b" strokeDasharray="3 3" />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke="#f59e0b"
                  strokeWidth={2.5}
                  dot={false}
                  activeDot={{ r: 4, fill: '#f59e0b' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 mt-2">
            💡 Option sellers benefit from this decay. ATM options decay fastest in last 7 days.
          </p>
        </div>

        {/* Probability Analysis */}
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-4 space-y-3">
          <p className="text-xs font-semibold text-white">🎯 Probability Analysis</p>

          <div className="bg-emerald-500/5 border border-emerald-500/25 rounded-lg p-3">
            <p className="text-[10px] text-slate-400 uppercase mb-1">ATM Call ITM Prob</p>
            <p className="text-2xl font-bold text-emerald-400 tabular-nums">{probabilityITM.ce.toFixed(1)}%</p>
            <p className="text-[10px] text-slate-500">Probability of expiring in-the-money</p>
          </div>

          <div className="bg-red-500/5 border border-red-500/25 rounded-lg p-3">
            <p className="text-[10px] text-slate-400 uppercase mb-1">ATM Put ITM Prob</p>
            <p className="text-2xl font-bold text-red-400 tabular-nums">{probabilityITM.pe.toFixed(1)}%</p>
            <p className="text-[10px] text-slate-500">Probability of expiring in-the-money</p>
          </div>

          <div className="bg-indigo-500/5 border border-indigo-500/25 rounded-lg p-3">
            <p className="text-[10px] text-slate-400 uppercase mb-1">POP (ATM Call Buy)</p>
            <p className="text-2xl font-bold text-indigo-400 tabular-nums">{popATMCall.toFixed(1)}%</p>
            <p className="text-[10px] text-slate-500">Probability of Profit for buyer</p>
          </div>
        </div>
      </div>

      {/* Row 3: Straddle + Risk/Reward + Position Sizing */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-5">
        {/* Straddle Analysis */}
        {straddleAnalysis && (
          <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/25 rounded-xl p-4">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">ATM Straddle Analysis</p>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Premium:</span>
                <span className="text-amber-400 font-bold tabular-nums">{formatCurrency(straddleAnalysis.totalPremium)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Upper BE:</span>
                <span className="text-emerald-400 font-semibold tabular-nums">{straddleAnalysis.upperBreakeven.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Lower BE:</span>
                <span className="text-red-400 font-semibold tabular-nums">{straddleAnalysis.lowerBreakeven.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-700">
                <span className="text-slate-400">Move Needed:</span>
                <span className="text-white font-bold tabular-nums">±{straddleAnalysis.movePercent.toFixed(2)}%</span>
              </div>
            </div>
            <p className="text-[10px] text-slate-500 mt-2">
              Market needs to move ±{straddleAnalysis.moveNeeded.toFixed(0)} pts for profit
            </p>
          </div>
        )}

        {/* Risk/Reward */}
        <div className={`rounded-xl p-4 border ${
          strategyLegs.length > 0
            ? 'bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/25'
            : 'bg-slate-800/40 border-slate-700/50'
        }`}>
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">Risk/Reward Ratio</p>
          {strategyLegs.length > 0 ? (
            <>
              <div className="flex items-end justify-between mb-2">
                <span className={`text-3xl font-bold tabular-nums ${riskReward.color}`}>
                  {riskReward.ratio >= 999 ? '∞' : riskReward.ratio.toFixed(2)}:1
                </span>
                <span className={`text-xs font-bold ${riskReward.color}`}>
                  {riskReward.rating}
                </span>
              </div>
              <div className="space-y-1 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Profit:</span>
                  <span className="text-emerald-400 font-semibold tabular-nums">{formatCurrency(strategyStats.maxProfit)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Max Loss:</span>
                  <span className="text-red-400 font-semibold tabular-nums">{formatCurrency(strategyStats.maxLoss)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Strategy Delta:</span>
                  <span className={`font-semibold tabular-nums ${strategyDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {strategyDelta >= 0 ? '+' : ''}{strategyDelta.toFixed(3)}
                  </span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 mt-2">{riskReward.message}</p>
            </>
          ) : (
            <p className="text-xs text-slate-500 py-8 text-center">Add strategy legs to see R:R</p>
          )}
        </div>

        {/* Position Sizing */}
        <div className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/25 rounded-xl p-4">
          <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mb-2">Position Sizing</p>

          <div className="space-y-2 mb-3">
            <div>
              <label className="text-[9px] text-slate-500 uppercase">Capital (₹)</label>
              <input
                type="number"
                value={userCapital}
                onChange={(e) => setUserCapital(Number(e.target.value))}
                className="w-full bg-slate-800 text-white text-sm rounded px-2 py-1 border border-slate-700 tabular-nums"
              />
            </div>
            <div>
              <label className="text-[9px] text-slate-500 uppercase">Win Rate (%)</label>
              <input
                type="number"
                value={winRate}
                onChange={(e) => setWinRate(Number(e.target.value))}
                min="1"
                max="99"
                className="w-full bg-slate-800 text-white text-sm rounded px-2 py-1 border border-slate-700 tabular-nums"
              />
            </div>
          </div>

          <div className="space-y-1 text-[10px] border-t border-slate-700 pt-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Kelly %:</span>
              <span className="text-blue-400 font-bold tabular-nums">{kelly.kellyPct.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Half Kelly:</span>
              <span className="text-cyan-400 font-bold tabular-nums">{kelly.halfKellyPct.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">2% Rule Lots:</span>
              <span className="text-emerald-400 font-bold tabular-nums">{fixedRisk.lots}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Risk Amount:</span>
              <span className="text-amber-400 font-bold tabular-nums">{formatCurrency(fixedRisk.riskAmount)}</span>
            </div>
          </div>
          <p className="text-[9px] text-slate-500 mt-2">{kelly.message}</p>
        </div>
      </div>

      {/* Row 4: Quick Reference Card */}
      <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-4">
        <p className="text-xs font-semibold text-white mb-3">📖 Quick Formula Reference</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[10px]">
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-purple-400 font-bold">IV Rank &gt; 80</p>
            <p className="text-slate-400">→ Sell options</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-emerald-400 font-bold">IV Rank &lt; 20</p>
            <p className="text-slate-400">→ Buy options</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-cyan-400 font-bold">PCR &gt; 1.3</p>
            <p className="text-slate-400">→ Bullish signal</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-red-400 font-bold">PCR &lt; 0.5</p>
            <p className="text-slate-400">→ Bearish signal</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-amber-400 font-bold">RSI &gt; 70</p>
            <p className="text-slate-400">→ Overbought</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-emerald-400 font-bold">RSI &lt; 30</p>
            <p className="text-slate-400">→ Oversold</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-pink-400 font-bold">Positive Skew</p>
            <p className="text-slate-400">→ Fear in market</p>
          </div>
          <div className="bg-slate-900/50 rounded p-2">
            <p className="text-indigo-400 font-bold">R:R &gt; 2:1</p>
            <p className="text-slate-400">→ Good trade</p>
          </div>
        </div>
      </div>
    </div>
  );
}
