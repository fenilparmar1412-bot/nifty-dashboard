interface RefreshSelectorProps {
  currentInterval: number;
  onChange: (ms: number) => void;
}

export default function RefreshSelector({ currentInterval, onChange }: RefreshSelectorProps) {
  const options = [
    { ms: 1000, label: '1s', desc: 'Ultra Fast' },
    { ms: 3000, label: '3s', desc: 'Fast' },
    { ms: 5000, label: '5s', desc: 'Normal' },
    { ms: 10000, label: '10s', desc: 'Slow' },
    { ms: 30000, label: '30s', desc: 'Battery Save' },
    { ms: 60000, label: '1m', desc: '1 Minute' },
  ];

  const current = options.find(o => o.ms === currentInterval) || options[1];

  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] text-slate-400 uppercase tracking-wider hidden sm:inline">Refresh:</span>
      <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-0.5 border border-slate-700">
        {options.map(opt => (
          <button
            key={opt.ms}
            onClick={() => onChange(opt.ms)}
            className={`px-2 py-1 text-[10px] font-semibold rounded transition-colors ${
              currentInterval === opt.ms
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
            title={opt.desc}
          >
            {opt.label}
          </button>
        ))}
      </div>
      <span className="text-[10px] text-slate-500 hidden sm:inline">
        ({current.desc})
      </span>
    </div>
  );
}
