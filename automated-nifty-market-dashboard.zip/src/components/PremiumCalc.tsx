import { useState, useMemo } from 'react';
import { calculateOptionPrice, formatCurrency } from '../utils/optionCalculations';

interface PremiumCalcProps {
  defaultSpot?: number;
  defaultStride?: number;
  defaultLotSize?: number;
}

export default function PremiumCalc({ defaultSpot = 23200, defaultStride = 50, defaultLotSize = 50 }: PremiumCalcProps) {
  const [spotPrice, setSpotPrice] = useState(defaultSpot);
  const [strikePrice, setStrikePrice] = useState(defaultSpot);
  const [optionType, setOptionType] = useState<'CE' | 'PE'>('CE');
  const [volatility, setVolatility] = useState(15);
  const [daysToExpiry, setDaysToExpiry] = useState(7);
  const [riskFreeRate, setRiskFreeRate] = useState(7);
  const [lotSize, setLotSize] = useState(defaultLotSize);

  const premium = useMemo(() => {
    return calculateOptionPrice({
      spotPrice,
      strikePrice,
      timeToExpiry: daysToExpiry / 365,
      volatility: volatility / 100,
      riskFreeRate: riskFreeRate / 100,
      optionType,
    });
  }, [spotPrice, strikePrice, optionType, volatility, daysToExpiry, riskFreeRate]);

  const totalCost = premium * lotSize;
  const intrinsicValue = optionType === 'CE'
    ? Math.max(0, spotPrice - strikePrice)
    : Math.max(0, strikePrice - spotPrice);
  const timeValue = Math.max(0, premium - intrinsicValue);
  const moneyness = optionType === 'CE'
    ? (strikePrice < spotPrice ? 'ITM' : strikePrice > spotPrice ? 'OTM' : 'ATM')
    : (strikePrice > spotPrice ? 'ITM' : strikePrice < spotPrice ? 'OTM' : 'ATM');

  const presetStrikes = useMemo(() => {
    const base = Math.round(spotPrice / defaultStride) * defaultStride;
    const strikes = [];
    for (let i = -3; i <= 3; i++) {
      strikes.push(base + i * defaultStride);
    }
    return strikes;
  }, [spotPrice, defaultStride]);

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <h2 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
        <svg className="w-5 h-5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        Premium Calculator
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Inputs */}
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Spot Price</label>
            <input
              type="number"
              value={spotPrice}
              onChange={(e) => setSpotPrice(Number(e.target.value))}
              className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2.5 border border-slate-700 tabular-nums font-mono"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Strike Price</label>
            <input
              type="number"
              value={strikePrice}
              onChange={(e) => setStrikePrice(Number(e.target.value))}
              className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2.5 border border-slate-700 tabular-nums font-mono"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Option Type</label>
            <div className="flex rounded-lg overflow-hidden border border-slate-700">
              <button
                onClick={() => setOptionType('CE')}
                className={`flex-1 py-2.5 text-sm font-semibold transition-colors ${optionType === 'CE' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
              >CALL (CE)</button>
              <button
                onClick={() => setOptionType('PE')}
                className={`flex-1 py-2.5 text-sm font-semibold transition-colors ${optionType === 'PE' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
              >PUT (PE)</button>
            </div>
          </div>
        </div>

        {/* More inputs */}
        <div className="space-y-3">
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Implied Volatility (%)</label>
            <input
              type="range"
              value={volatility}
              onChange={(e) => setVolatility(Number(e.target.value))}
              min="5"
              max="80"
              step="0.5"
              className="w-full accent-indigo-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-0.5">
              <span>5%</span>
              <span className="text-indigo-400 font-semibold">{volatility}%</span>
              <span>80%</span>
            </div>
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Days to Expiry</label>
            <input
              type="range"
              value={daysToExpiry}
              onChange={(e) => setDaysToExpiry(Number(e.target.value))}
              min="1"
              max="30"
              className="w-full accent-indigo-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-0.5">
              <span>1</span>
              <span className="text-indigo-400 font-semibold">{daysToExpiry}d</span>
              <span>30</span>
            </div>
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Risk-Free Rate (%)</label>
            <input
              type="number"
              value={riskFreeRate}
              onChange={(e) => setRiskFreeRate(Number(e.target.value))}
              className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2.5 border border-slate-700 tabular-nums"
              step="0.1"
            />
          </div>
          <div>
            <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Lot Size</label>
            <input
              type="number"
              value={lotSize}
              onChange={(e) => setLotSize(Number(e.target.value))}
              className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2.5 border border-slate-700 tabular-nums"
              step="25"
            />
          </div>
        </div>

        {/* Results */}
        <div className="space-y-3">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Calculated Premium</div>

          <div className="bg-slate-800/60 rounded-xl p-4 border border-slate-700/50">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-400">Per Share</span>
              <span className={`text-2xl font-bold tabular-nums tracking-tight ${
                optionType === 'CE' ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {formatCurrency(premium)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Total (×{lotSize})</span>
              <span className="text-lg font-semibold text-white tabular-nums">
                {formatCurrency(totalCost)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-slate-800/40 rounded-lg p-2.5 text-center">
              <p className="text-[10px] text-slate-500 uppercase">Intrinsic</p>
              <p className="text-sm font-semibold text-white tabular-nums">{formatCurrency(intrinsicValue)}</p>
            </div>
            <div className="bg-slate-800/40 rounded-lg p-2.5 text-center">
              <p className="text-[10px] text-slate-500 uppercase">Time Value</p>
              <p className="text-sm font-semibold text-white tabular-nums">{formatCurrency(timeValue)}</p>
            </div>
          </div>

          <div className={`px-3 py-2 rounded-lg text-center text-xs font-semibold ${
            moneyness === 'ATM' ? 'bg-amber-500/15 text-amber-400 border border-amber-500/25' :
            moneyness === 'ITM' ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25' :
            'bg-slate-800 text-slate-400'
          }`}>
            {moneyness} Option
          </div>
        </div>
      </div>

      {/* Quick Strike Selection */}
      <div className="mt-4 pt-4 border-t border-slate-700/50">
        <p className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Quick Strike Selection (ATM ±150)</p>
        <div className="flex flex-wrap gap-1.5">
          {presetStrikes.map(strike => (
            <button
              key={strike}
              onClick={() => setStrikePrice(strike)}
              className={`px-3 py-1.5 text-xs rounded-lg font-semibold transition-all tabular-nums ${
                strikePrice === strike
                  ? (optionType === 'CE' ? 'bg-amber-600 text-white shadow-lg shadow-amber-500/20' : 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20')
                  : Math.abs(strike - spotPrice) < 50
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/25'
                    : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
              }`}
            >
              {strike.toLocaleString('en-IN')}
              {Math.abs(strike - spotPrice) < 50 && <span className="ml-1 text-[10px] opacity-70">ATM</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
