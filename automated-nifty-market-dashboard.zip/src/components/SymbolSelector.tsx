import { useState, useRef, useEffect } from 'react';
import { SymbolConfig, INDICES, STOCKS } from '../utils/symbols';

interface SymbolSelectorProps {
  currentSymbol: string;
  onChange: (symbol: string) => void;
}

export default function SymbolSelector({ currentSymbol, onChange }: SymbolSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'INDICES' | 'STOCKS'>('INDICES');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const current = [...INDICES, ...STOCKS].find(s => s.symbol === currentSymbol) || INDICES[0];

  const filtered = (activeTab === 'INDICES' ? INDICES : STOCKS).filter(s =>
    s.symbol.toLowerCase().includes(search.toLowerCase()) ||
    s.displayName.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (config: SymbolConfig) => {
    onChange(config.symbol);
    setIsOpen(false);
    setSearch('');
  };

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 hover:border-indigo-500/50 transition-colors"
      >
        <div className={`w-2 h-2 rounded-full ${current.type === 'INDEX' ? 'bg-amber-400' : 'bg-cyan-400'}`} />
        <div className="text-left">
          <div className="text-sm font-bold text-white">{current.displayName}</div>
          <div className="text-[10px] text-slate-500 uppercase tracking-wider">
            {current.type} • Lot: {current.lotSize}
          </div>
        </div>
        <svg className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute top-full mt-2 left-0 w-80 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl shadow-black/50 z-50 overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-slate-700">
            <button
              onClick={() => { setActiveTab('INDICES'); setSearch(''); }}
              className={`flex-1 py-2.5 text-xs font-semibold transition-colors ${
                activeTab === 'INDICES' ? 'bg-slate-800 text-amber-400 border-b-2 border-amber-400' : 'text-slate-400'
              }`}
            >
              📊 Indices ({INDICES.length})
            </button>
            <button
              onClick={() => { setActiveTab('STOCKS'); setSearch(''); }}
              className={`flex-1 py-2.5 text-xs font-semibold transition-colors ${
                activeTab === 'STOCKS' ? 'bg-slate-800 text-cyan-400 border-b-2 border-cyan-400' : 'text-slate-400'
              }`}
            >
              🏢 Stocks ({STOCKS.length})
            </button>
          </div>

          {/* Search */}
          <div className="p-3 border-b border-slate-700">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search symbol..."
              autoFocus
              className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 focus:border-indigo-500 outline-none"
            />
          </div>

          {/* List */}
          <div className="max-h-96 overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="p-4 text-center text-sm text-slate-500">No symbols found</div>
            ) : (
              filtered.map(config => (
                <button
                  key={config.symbol}
                  onClick={() => handleSelect(config)}
                  className={`w-full px-4 py-3 flex items-center justify-between hover:bg-slate-800 transition-colors border-b border-slate-800/50 ${
                    config.symbol === currentSymbol ? 'bg-indigo-500/10' : ''
                  }`}
                >
                  <div className="text-left">
                    <div className="text-sm font-bold text-white">{config.displayName}</div>
                    <div className="text-[10px] text-slate-500 uppercase">
                      {config.sector} • Lot: {config.lotSize} • Stride: ₹{config.strikeStride}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-semibold text-slate-300 tabular-nums">~₹{config.basePrice.toLocaleString('en-IN')}</div>
                    <div className="text-[10px] text-slate-500">IV: {config.avgIV}%</div>
                  </div>
                </button>
              ))
            )}
          </div>

          {/* Footer info */}
          <div className="px-4 py-2 bg-slate-800/50 border-t border-slate-700 text-[10px] text-slate-500">
            💡 Strike Stride = gap between strikes • Lot = 1 lot size
          </div>
        </div>
      )}
    </div>
  );
}
