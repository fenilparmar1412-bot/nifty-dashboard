import { useState, useCallback } from 'react';
import LiveTicker from './LiveTicker';
import OptionChain from './OptionChain';
import StrategyBuilder from './StrategyBuilder';
import PayoffChart from './PayoffChart';
import GreeksPanel from './GreeksPanel';
import PremiumCalc from './PremiumCalc';
import DailyGuide from './DailyGuide';
import SymbolSelector from './SymbolSelector';
import RSIPanel from './RSIPanel';
import MarketAnalysis from './MarketAnalysis';
import AdvancedAnalytics from './AdvancedAnalytics';
import StrikeSentimentPanel from './StrikeSentiment';
import RefreshSelector from './RefreshSelector';
import { Strategy, StrategyLeg } from '../types';
import { useNiftyData } from '../hooks/useNiftyData';

export default function Dashboard() {
  const [currentSymbol, setCurrentSymbol] = useState<string>('NIFTY');
  const [refreshInterval, setRefreshInterval] = useState<number>(3000);
  const { symbol, index, optionChain, expiryDates, loading, lastUpdated, refresh, marketStatus, dataSource, priceHistory } = useNiftyData(currentSymbol, refreshInterval);

  const [strategy, setStrategy] = useState<Strategy>({
    id: '',
    name: '',
    legs: [],
  });

  const [selectedStrikes, setSelectedStrikes] = useState<number[]>([]);

  const handleAddLeg = useCallback((leg: StrategyLeg) => {
    setStrategy(prev => ({
      id: prev.id || 'custom',
      name: prev.name || 'Custom Strategy',
      legs: [...prev.legs, leg],
    }));
    setSelectedStrikes(prev => [...prev, leg.strikePrice]);
  }, []);

  const handleUpdateStrategy = useCallback((newStrategy: Strategy) => {
    setStrategy(newStrategy);
    setSelectedStrikes(newStrategy.legs.map(l => l.strikePrice));
  }, []);

  const handleSymbolChange = useCallback((newSymbol: string) => {
    setCurrentSymbol(newSymbol);
    // Clear strategy when changing symbol
    setStrategy({ id: '', name: '', legs: [] });
    setSelectedStrikes([]);
  }, []);

  const spotPrice = index?.spotPrice || symbol.basePrice;

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Top Bar with Symbol Selector */}
      <div className="bg-slate-900 border-b border-slate-800">
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">Advanced Options Suite</h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest">Pro Trading Dashboard</p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <RefreshSelector currentInterval={refreshInterval} onChange={setRefreshInterval} />
            <SymbolSelector currentSymbol={currentSymbol} onChange={handleSymbolChange} />
          </div>
        </div>
      </div>

      {/* Live Ticker */}
      <LiveTicker
        index={index}
        lastUpdated={lastUpdated}
        loading={loading}
        marketStatus={marketStatus}
        dataSource={dataSource}
        onRefresh={refresh}
      />

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-4 py-4 space-y-4">
        {/* Market Analysis Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <MarketAnalysis
              optionChain={optionChain}
              spotPrice={spotPrice}
            />
          </div>
          <div className="lg:col-span-1">
            <RSIPanel
              priceHistory={priceHistory}
            />
          </div>
        </div>

        {/* Strike Sentiment - Bullish vs Bearish */}
        <StrikeSentimentPanel
          optionChain={optionChain}
          spotPrice={spotPrice}
          onAddLeg={handleAddLeg}
        />

        {/* Option Chain + Premium Calculator */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <OptionChain
              data={optionChain}
              spotPrice={spotPrice}
              onAddLeg={handleAddLeg}
              selectedStrikes={selectedStrikes}
              strikeStride={symbol.strikeStride}
            />
          </div>
          <div className="lg:col-span-1">
            <PremiumCalc defaultSpot={spotPrice} defaultStride={symbol.strikeStride} defaultLotSize={symbol.lotSize} />
          </div>
        </div>

        {/* Strategy Builder + Payoff Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <StrategyBuilder
            strategy={strategy}
            onUpdateStrategy={handleUpdateStrategy}
            spotPrice={spotPrice}
            optionChain={optionChain}
            lotSize={symbol.lotSize}
          />
          <PayoffChart
            strategy={strategy}
            spotPrice={spotPrice}
          />
        </div>

        {/* Advanced Analytics with 12 Pro Formulas */}
        <AdvancedAnalytics
          optionChain={optionChain}
          spotPrice={spotPrice}
          lotSize={symbol.lotSize}
          strategyLegs={strategy.legs}
        />

        {/* Greeks Panel */}
        <GreeksPanel
          strategy={strategy}
          spotPrice={spotPrice}
          optionChain={optionChain}
        />

        {/* Footer */}
        <div className="text-center py-6 text-xs text-slate-600 space-y-1">
          <p className="text-sm font-semibold text-slate-400">
            {symbol.displayName} Options — Advanced Trading Dashboard
          </p>
          <p>
            Lot Size: <span className="text-white font-semibold">{symbol.lotSize}</span> •
            Strike Stride: <span className="text-white font-semibold">₹{symbol.strikeStride}</span> •
            Total Strikes: <span className="text-white font-semibold">{optionChain.length}</span>
          </p>
          <p>Expiry Dates: <span className="text-slate-400">{expiryDates.join(' | ')}</span></p>
          <p className="mt-2 text-slate-700">
            ⚠ Disclaimer: Educational tool only. Verify data before trading. Not SEBI-registered advice.
          </p>
        </div>
      </div>

      {/* Daily Guide & Market Status */}
      <DailyGuide />
    </div>
  );
}
