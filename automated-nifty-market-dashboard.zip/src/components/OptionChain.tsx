import { useMemo, useState } from 'react';
import { OptionData, StrategyLeg } from '../types';
import { formatIndianNumber } from '../utils/optionCalculations';
import { calculateStrikeSentiment } from '../utils/sentimentAnalysis';

interface OptionChainProps {
  data: OptionData[];
  spotPrice: number;
  onAddLeg: (leg: StrategyLeg) => void;
  selectedStrikes: number[];
  strikeStride: number;
}

type FilterType = 'ALL' | 'ATM' | 'ITM_CE' | 'ITM_PE' | 'OTM' | 'ACTIVE' | 'ITM_ALL' | 'BULLISH' | 'BEARISH';
type SortType = 'STRIKE' | 'OI' | 'VOLUME' | 'CHANGE';

export default function OptionChain({ data, spotPrice, onAddLeg, selectedStrikes, strikeStride }: OptionChainProps) {
  const [filter, setFilter] = useState<FilterType>('ATM');
  const [sort, setSort] = useState<SortType>('STRIKE');
  const [strikeRange, setStrikeRange] = useState<number>(15); // ±15 strikes from ATM

  const atmStrike = useMemo(() => {
    if (!data.length) return Math.round(spotPrice / strikeStride) * strikeStride;
    return data.reduce((prev, curr) =>
      Math.abs(curr.strikePrice - spotPrice) < Math.abs(prev.strikePrice - spotPrice) ? curr : prev
    ).strikePrice;
  }, [data, spotPrice, strikeStride]);

  const maxOI = useMemo(() => {
    let max = 0;
    data.forEach(d => {
      if (d.ce.openInterest > max) max = d.ce.openInterest;
      if (d.pe.openInterest > max) max = d.pe.openInterest;
    });
    return max;
  }, [data]);

  // Get "Most Active" strikes (top 15 by OI)
  const activeStrikes = useMemo(() => {
    const sorted = [...data].sort((a, b) => {
      const aOI = a.ce.openInterest + a.pe.openInterest;
      const bOI = b.ce.openInterest + b.pe.openInterest;
      return bOI - aOI;
    });
    return new Set(sorted.slice(0, 15).map(d => d.strikePrice));
  }, [data]);

  const filteredData = useMemo(() => {
    if (!data.length) return [];

    let filtered = data;

    switch (filter) {
      case 'ATM':
        filtered = data.filter(d =>
          Math.abs(d.strikePrice - atmStrike) <= strikeRange * strikeStride
        );
        break;
      case 'ITM_CE':
        filtered = data.filter(d => d.strikePrice < spotPrice);
        break;
      case 'ITM_PE':
        filtered = data.filter(d => d.strikePrice > spotPrice);
        break;
      case 'ITM_ALL':
        filtered = data.filter(d => d.strikePrice !== atmStrike && (
          (d.strikePrice < spotPrice) || (d.strikePrice > spotPrice)
        ));
        break;
      case 'OTM':
        filtered = data.filter(d =>
          (d.strikePrice > spotPrice && d.strikePrice > atmStrike) ||
          (d.strikePrice < spotPrice && d.strikePrice < atmStrike)
        ).filter(d => Math.abs(d.strikePrice - spotPrice) > strikeStride * 2);
        break;
      case 'ACTIVE':
        filtered = data.filter(d => activeStrikes.has(d.strikePrice));
        break;
      case 'BULLISH':
        filtered = data.filter(d => {
          const s = calculateStrikeSentiment(d, spotPrice, maxOI);
          return s.score >= 15;
        });
        break;
      case 'BEARISH':
        filtered = data.filter(d => {
          const s = calculateStrikeSentiment(d, spotPrice, maxOI);
          return s.score <= -15;
        });
        break;
    }

    // Sort
    switch (sort) {
      case 'STRIKE':
        filtered = filtered.sort((a, b) => b.strikePrice - a.strikePrice);
        break;
      case 'OI':
        filtered = filtered.sort((a, b) =>
          (b.ce.openInterest + b.pe.openInterest) - (a.ce.openInterest + a.pe.openInterest)
        );
        break;
      case 'VOLUME':
        filtered = filtered.sort((a, b) =>
          (b.ce.volume + b.pe.volume) - (a.ce.volume + a.pe.volume)
        );
        break;
      case 'CHANGE':
        filtered = filtered.sort((a, b) =>
          (Math.abs(b.ce.change) + Math.abs(b.pe.change)) - (Math.abs(a.ce.change) + Math.abs(a.pe.change))
        );
        break;
    }

    return filtered;
  }, [data, filter, sort, spotPrice, atmStrike, strikeRange, strikeStride, activeStrikes, maxOI]);

  const getStrikeHighlight = (strike: number) => {
    if (selectedStrikes.includes(strike)) return 'bg-indigo-500/10 border-l-2 border-l-indigo-500';
    if (Math.abs(strike - spotPrice) < strikeStride / 2) return 'bg-amber-500/5';
    return '';
  };

  // Liquidity badge
  const getLiquidityBadge = (row: OptionData) => {
    const totalOI = row.ce.openInterest + row.pe.openInterest;
    const percentile = totalOI / (maxOI * 2);
    if (percentile > 0.7) return <span className="text-[9px] px-1 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">HOT</span>;
    if (percentile > 0.4) return <span className="text-[9px] px-1 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-bold">ACTIVE</span>;
    return null;
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-700/50 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-base font-semibold text-white flex items-center gap-2">
            <svg className="w-5 h-5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M3 14h18m-9-4v8" />
            </svg>
            Option Chain
            <span className="text-xs text-slate-500 font-normal">({filteredData.length} strikes)</span>
          </h2>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-500 uppercase">Sort:</span>
            {(['STRIKE', 'OI', 'VOLUME', 'CHANGE'] as SortType[]).map(s => (
              <button
                key={s}
                onClick={() => setSort(s)}
                className={`px-2 py-1 text-[10px] font-semibold rounded transition-colors ${
                  sort === s ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            {([
              { key: 'BULLISH', label: '📈 Bullish' },
              { key: 'BEARISH', label: '📉 Bearish' },
              { key: 'ACTIVE', label: '🔥 Most Active' },
              { key: 'ATM', label: 'ATM Range' },
              { key: 'ALL', label: 'All Strikes' },
              { key: 'ITM_CE', label: 'ITM (CE)' },
              { key: 'ITM_PE', label: 'ITM (PE)' },
              { key: 'OTM', label: 'OTM' },
            ] as { key: FilterType; label: string }[]).map(f => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                  filter === f.key
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {filter === 'ATM' && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-slate-500 uppercase">Range:</span>
              <input
                type="range"
                min="5"
                max="30"
                value={strikeRange}
                onChange={(e) => setStrikeRange(Number(e.target.value))}
                className="w-32 accent-indigo-500"
              />
              <span className="text-xs text-indigo-400 font-semibold tabular-nums w-16 text-right">
                ±{strikeRange} ({filteredData.length})
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-[650px] overflow-y-auto">
        <table className="w-full text-xs group">
          <thead className="sticky top-0 z-10">
            <tr className="bg-slate-800/80 backdrop-blur-sm">
              <th colSpan={7} className="px-2 py-2 text-left text-[11px] font-semibold text-amber-400/80 uppercase tracking-wider bg-amber-500/5">
                CALL (CE)
              </th>
              <th className="px-3 py-2 text-center text-[11px] font-bold text-white uppercase tracking-wider bg-slate-700/50">
                STRIKE
              </th>
              <th colSpan={7} className="px-2 py-2 text-right text-[11px] font-semibold text-emerald-400/80 uppercase tracking-wider bg-emerald-500/5">
                PUT (PE)
              </th>
            </tr>
            <tr className="bg-slate-850">
              {['OI', 'Chg OI', 'Vol', 'LTP', 'Chg', 'Bid', 'Ask'].map(h => (
                <th key={`ce-${h}`} className="px-2 py-2 text-right text-[10px] font-medium text-slate-500 uppercase tracking-wide">{h}</th>
              ))}
              <th className="px-3 py-2 bg-slate-700/30" />
              {['Ask', 'Bid', 'Chg', 'LTP', 'Vol', 'Chg OI', 'OI'].map(h => (
                <th key={`pe-${h}`} className="px-2 py-2 text-left text-[10px] font-medium text-slate-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredData.map((row) => {
              const isATM = Math.abs(row.strikePrice - spotPrice) < strikeStride / 2;
              const ceBars = row.ce.openInterest / maxOI * 60;
              const peBars = row.pe.openInterest / maxOI * 60;
              return (
                <tr
                  key={row.strikePrice}
                  className={`border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors ${
                    isATM ? 'bg-amber-500/5' : ''
                  } ${getStrikeHighlight(row.strikePrice)}`}
                >
                  {/* CE Columns */}
                  <td className="px-2 py-1.5 text-right relative">
                    <div className="absolute right-0 top-0 bottom-0 bg-amber-500/8" style={{ width: `${ceBars}%` }} />
                    <span className="relative text-slate-400 tabular-nums">{formatIndianNumber(row.ce.openInterest)}</span>
                  </td>
                  <td className={`px-2 py-1.5 text-right tabular-nums ${row.ce.changeInOI >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {formatIndianNumber(row.ce.changeInOI)}
                  </td>
                  <td className="px-2 py-1.5 text-right text-slate-500 tabular-nums">{formatIndianNumber(row.ce.volume)}</td>
                  <td className="px-2 py-1.5 text-right text-amber-400 font-semibold tabular-nums">{row.ce.lastPrice.toFixed(2)}</td>
                  <td className={`px-2 py-1.5 text-right tabular-nums ${row.ce.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {row.ce.change.toFixed(2)}
                  </td>
                  <td className="px-2 py-1.5 text-right text-blue-400 tabular-nums">{row.ce.bid.toFixed(2)}</td>
                  <td className="px-2 py-1.5 text-right text-blue-300 tabular-nums">{row.ce.ask.toFixed(2)}</td>

                  {/* Strike */}
                  <td className="px-3 py-1.5 text-center bg-slate-800/40 relative">
                    {/* Sentiment indicator bar on left */}
                    {(() => {
                      const sentiment = calculateStrikeSentiment(row, spotPrice, maxOI);
                      const isBullish = sentiment.score > 0;
                      const width = Math.min(100, Math.abs(sentiment.score));
                      return (
                        <div
                          className={`absolute left-0 top-0 bottom-0 ${isBullish ? 'bg-emerald-500/20' : 'bg-red-500/20'}`}
                          style={{ width: `${width}%` }}
                          title={`${sentiment.signal} (${sentiment.score.toFixed(0)})`}
                        />
                      );
                    })()}
                    <div className="relative flex items-center justify-center gap-1">
                      <button
                        onClick={() => onAddLeg({ type: 'CE', action: 'BUY', strikePrice: row.strikePrice, premium: row.ce.ask, quantity: 50 })}
                        className="text-[9px] px-1 py-0.5 rounded bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/40 transition-all opacity-60 hover:opacity-100"
                        title="Buy CE"
                      >C+</button>
                      <div className="flex flex-col items-center">
                        <div className="flex items-center gap-1">
                          <span className={`font-bold text-sm tabular-nums ${isATM ? 'text-amber-400' : 'text-white'}`}>
                            {row.strikePrice.toLocaleString('en-IN')}
                          </span>
                          {isATM && <span className="text-[8px] px-1 rounded bg-amber-500/30 text-amber-300">ATM</span>}
                        </div>
                        {getLiquidityBadge(row)}
                      </div>
                      <button
                        onClick={() => onAddLeg({ type: 'PE', action: 'BUY', strikePrice: row.strikePrice, premium: row.pe.ask, quantity: 50 })}
                        className="text-[9px] px-1 py-0.5 rounded bg-red-600/20 text-red-400 hover:bg-red-600/40 transition-all opacity-60 hover:opacity-100"
                        title="Buy PE"
                      >P+</button>
                    </div>
                  </td>

                  {/* PE Columns */}
                  <td className="px-2 py-1.5 text-left text-blue-300 tabular-nums">{row.pe.ask.toFixed(2)}</td>
                  <td className="px-2 py-1.5 text-left text-blue-400 tabular-nums">{row.pe.bid.toFixed(2)}</td>
                  <td className={`px-2 py-1.5 text-left tabular-nums ${row.pe.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {row.pe.change.toFixed(2)}
                  </td>
                  <td className="px-2 py-1.5 text-left text-emerald-400 font-semibold tabular-nums">{row.pe.lastPrice.toFixed(2)}</td>
                  <td className="px-2 py-1.5 text-left text-slate-500 tabular-nums">{formatIndianNumber(row.pe.volume)}</td>
                  <td className={`px-2 py-1.5 text-left tabular-nums ${row.pe.changeInOI >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {formatIndianNumber(row.pe.changeInOI)}
                  </td>
                  <td className="px-2 py-1.5 text-left relative">
                    <div className="absolute left-0 top-0 bottom-0 bg-emerald-500/8" style={{ width: `${peBars}%` }} />
                    <span className="relative text-slate-400 tabular-nums">{formatIndianNumber(row.pe.openInterest)}</span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="px-5 py-3 bg-slate-800/30 border-t border-slate-700/50 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500">
        <div className="flex items-center gap-3 flex-wrap">
          <span>ATM: <span className="text-amber-400 font-bold">{atmStrike.toLocaleString('en-IN')}</span></span>
          <span>Stride: <span className="text-white font-semibold">₹{strikeStride}</span></span>
          <span>Total Strikes: <span className="text-white font-semibold">{data.length}</span></span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1"><span className="text-[9px] px-1 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">HOT</span> = Most liquid</span>
          <span className="flex items-center gap-1"><span className="text-[9px] px-1 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-bold">ACTIVE</span> = Good liquidity</span>
        </div>
      </div>
    </div>
  );
}
