import { useMemo } from 'react';
import { OptionData, StrategyLeg } from '../types';
import {
  analyzeChainSentiment,
  getMarketSentiment,
  StrikeSentiment,
} from '../utils/sentimentAnalysis';

interface StrikeSentimentPanelProps {
  optionChain: OptionData[];
  spotPrice: number;
  onAddLeg?: (leg: StrategyLeg) => void;
}

export default function StrikeSentimentPanel({ optionChain, spotPrice, onAddLeg }: StrikeSentimentPanelProps) {
  const sentimentData = useMemo(() => {
    return analyzeChainSentiment(optionChain, spotPrice);
  }, [optionChain, spotPrice]);

  const marketSentiment = useMemo(() => {
    return getMarketSentiment(optionChain, spotPrice);
  }, [optionChain, spotPrice]);

  const topBullish = sentimentData.filter(s => s.score >= 15).slice(0, 6);
  const topBearish = sentimentData.filter(s => s.score <= -15).slice(0, 6);

  const renderStrikeCard = (s: StrikeSentiment, isBullish: boolean) => (
    <div
      key={s.strikePrice}
      className={`relative overflow-hidden rounded-xl border ${s.borderColor} ${s.bgColor} p-3 transition-all hover:scale-[1.02] cursor-pointer`}
      onClick={() => {
        if (!onAddLeg) return;
        onAddLeg({
          type: isBullish ? 'CE' : 'PE',
          action: 'BUY',
          strikePrice: s.strikePrice,
          premium: 50,
          quantity: 25,
        });
      }}
      title={onAddLeg ? `Click to add ${isBullish ? 'Buy CE' : 'Buy PE'} at ${s.strikePrice}` : ''}
    >
      {/* Score bar background */}
      <div
        className={`absolute top-0 bottom-0 ${isBullish ? 'left-0 bg-emerald-500/10' : 'right-0 bg-red-500/10'}`}
        style={{ width: `${Math.abs(s.score)}%` }}
      />

      <div className="relative">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{s.icon}</span>
            <div>
              <p className={`text-xl font-bold tabular-nums ${s.color}`}>
                {s.strikePrice.toLocaleString('en-IN')}
              </p>
              <p className={`text-[10px] font-bold uppercase ${s.color}`}>{s.signal}</p>
            </div>
          </div>
          <div className="text-right">
            <p className={`text-lg font-bold tabular-nums ${s.color}`}>
              {s.score > 0 ? '+' : ''}{s.score.toFixed(0)}
            </p>
            <p className="text-[9px] text-slate-500">Score</p>
          </div>
        </div>

        {/* Strength bars */}
        <div className="space-y-1 mb-2">
          <div className="flex items-center gap-2 text-[10px]">
            <span className="text-emerald-400 w-16">Support</span>
            <div className="flex-1 h-1.5 bg-slate-700/50 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-green-400 rounded-full transition-all"
                style={{ width: `${s.supportStrength}%` }}
              />
            </div>
            <span className="text-slate-400 tabular-nums w-8 text-right">{s.supportStrength.toFixed(0)}</span>
          </div>
          <div className="flex items-center gap-2 text-[10px]">
            <span className="text-red-400 w-16">Resistance</span>
            <div className="flex-1 h-1.5 bg-slate-700/50 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-500 to-rose-400 rounded-full transition-all"
                style={{ width: `${s.resistanceStrength}%` }}
              />
            </div>
            <span className="text-slate-400 tabular-nums w-8 text-right">{s.resistanceStrength.toFixed(0)}</span>
          </div>
        </div>

        {/* Reasons */}
        <div className="space-y-0.5">
          {s.reason.map((r, i) => (
            <p key={i} className="text-[10px] text-slate-400 truncate">{r}</p>
          ))}
        </div>

        {/* Action */}
        <div className={`mt-2 pt-2 border-t border-slate-700/50 text-[10px] font-semibold ${s.color}`}>
          💡 {s.action}
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      {/* Header with Overall Sentiment */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <h2 className="text-base font-semibold text-white flex items-center gap-2">
          <svg className="w-5 h-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          Strike Sentiment — Bullish vs Bearish
        </h2>

        <div className="flex items-center gap-3">
          <div className={`px-4 py-2 rounded-xl ${marketSentiment.color.includes('emerald') ? 'bg-emerald-500/15 border-emerald-500/30' : marketSentiment.color.includes('red') ? 'bg-red-500/15 border-red-500/30' : 'bg-amber-500/15 border-amber-500/30'} border`}>
            <p className="text-[10px] text-slate-400 uppercase">Overall Sentiment</p>
            <p className={`text-sm font-bold ${marketSentiment.color}`}>{marketSentiment.label}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-slate-400 uppercase">Score</p>
            <p className={`text-2xl font-bold tabular-nums ${marketSentiment.color}`}>
              {marketSentiment.overallScore > 0 ? '+' : ''}{marketSentiment.overallScore.toFixed(1)}
            </p>
          </div>
        </div>
      </div>

      {/* Strike Count Summary */}
      <div className="grid grid-cols-3 gap-2 mb-5">
        <div className="bg-emerald-500/10 border border-emerald-500/25 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-emerald-400 tabular-nums">{marketSentiment.bullishStrikes}</p>
          <p className="text-[10px] text-slate-400 uppercase mt-1">📈 Bullish Strikes</p>
        </div>
        <div className="bg-slate-700/30 border border-slate-700 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-slate-300 tabular-nums">{marketSentiment.neutralStrikes}</p>
          <p className="text-[10px] text-slate-400 uppercase mt-1">⚖️ Neutral</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/25 rounded-lg p-3 text-center">
          <p className="text-2xl font-bold text-red-400 tabular-nums">{marketSentiment.bearishStrikes}</p>
          <p className="text-[10px] text-slate-400 uppercase mt-1">📉 Bearish Strikes</p>
        </div>
      </div>

      {/* Support & Resistance Levels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
        <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
          <p className="text-xs font-bold text-emerald-400 mb-2 flex items-center gap-2">
            <span className="text-lg">🛡️</span>
            Strong Support Levels (Put Walls)
          </p>
          <div className="flex flex-wrap gap-2">
            {marketSentiment.supportLevels.map(level => (
              <div key={level} className="px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/30">
                <p className="text-sm font-bold text-emerald-400 tabular-nums">{level.toLocaleString('en-IN')}</p>
              </div>
            ))}
            {marketSentiment.supportLevels.length === 0 && (
              <p className="text-xs text-slate-500">No strong support detected</p>
            )}
          </div>
          <p className="text-[10px] text-slate-500 mt-2">💡 Price likely to bounce from these levels</p>
        </div>

        <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4">
          <p className="text-xs font-bold text-red-400 mb-2 flex items-center gap-2">
            <span className="text-lg">🧱</span>
            Strong Resistance Levels (Call Walls)
          </p>
          <div className="flex flex-wrap gap-2">
            {marketSentiment.resistanceLevels.map(level => (
              <div key={level} className="px-3 py-1.5 rounded-lg bg-red-500/20 border border-red-500/30">
                <p className="text-sm font-bold text-red-400 tabular-nums">{level.toLocaleString('en-IN')}</p>
              </div>
            ))}
            {marketSentiment.resistanceLevels.length === 0 && (
              <p className="text-xs text-slate-500">No strong resistance detected</p>
            )}
          </div>
          <p className="text-[10px] text-slate-500 mt-2">💡 Price likely to face selling pressure here</p>
        </div>
      </div>

      {/* Bullish vs Bearish Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bullish Strikes */}
        <div>
          <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-2">
            <span className="text-xl">📈</span>
            Top BULLISH Strikes
            <span className="text-[10px] text-slate-500 font-normal">— Traders expecting UP move</span>
          </h3>
          <div className="space-y-2">
            {topBullish.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 text-center">No strong bullish signals right now</p>
            ) : (
              topBullish.map(s => renderStrikeCard(s, true))
            )}
          </div>
        </div>

        {/* Bearish Strikes */}
        <div>
          <h3 className="text-sm font-bold text-red-400 mb-3 flex items-center gap-2">
            <span className="text-xl">📉</span>
            Top BEARISH Strikes
            <span className="text-[10px] text-slate-500 font-normal">— Traders expecting DOWN move</span>
          </h3>
          <div className="space-y-2">
            {topBearish.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 text-center">No strong bearish signals right now</p>
            ) : (
              topBearish.map(s => renderStrikeCard(s, false))
            )}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-5 p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl">
        <p className="text-xs font-semibold text-white mb-2">📖 How to Read Sentiment</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] text-slate-400">
          <div className="space-y-1">
            <p><span className="text-emerald-400 font-bold">✍️ Put Writing</span> = Support building (BULLISH)</p>
            <p><span className="text-emerald-400 font-bold">🚀 Call Unwinding</span> = Resistance broken (BULLISH)</p>
            <p><span className="text-emerald-400 font-bold">📈 Call Long Buildup</span> = Traders buying calls (BULLISH)</p>
          </div>
          <div className="space-y-1">
            <p><span className="text-red-400 font-bold">✍️ Call Writing</span> = Resistance building (BEARISH)</p>
            <p><span className="text-red-400 font-bold">📉 Put Unwinding</span> = Support broken (BEARISH)</p>
            <p><span className="text-red-400 font-bold">📉 Put Long Buildup</span> = Traders buying puts (BEARISH)</p>
          </div>
        </div>
        <div className="mt-2 pt-2 border-t border-slate-700/50 text-[10px] text-slate-500">
          💡 <span className="text-amber-400 font-bold">Tip:</span> Click any strike card to quickly add it to your strategy!
        </div>
      </div>
    </div>
  );
}
