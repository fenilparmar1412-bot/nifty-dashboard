import { useMemo, useState } from 'react';
import { Strategy, OptionData, Greeks } from '../types';
import { calculateGreeks, calculateTotalStrategyGreeks } from '../utils/optionCalculations';

interface GreeksPanelProps {
  strategy: Strategy;
  spotPrice: number;
  optionChain: OptionData[];
}

export default function GreeksPanel({ strategy, spotPrice, optionChain }: GreeksPanelProps) {
  const [customStrike, setCustomStrike] = useState<number>(Math.round(spotPrice / 50) * 50);
  const [customType, setCustomType] = useState<'CE' | 'PE'>('CE');
  const [customIV, setCustomIV] = useState<number>(15);
  const [daysToExpiry, setDaysToExpiry] = useState<number>(7);
  const [riskFreeRate, setRiskFreeRate] = useState<number>(7);

  const customGreeks: Greeks = useMemo(() => {
    return calculateGreeks({
      spotPrice,
      strikePrice: customStrike,
      timeToExpiry: daysToExpiry / 365,
      volatility: customIV / 100,
      riskFreeRate: riskFreeRate / 100,
      optionType: customType,
    });
  }, [spotPrice, customStrike, customType, customIV, daysToExpiry, riskFreeRate]);

  const strategyGreeks: Greeks | null = useMemo(() => {
    if (strategy.legs.length === 0) return null;
    const avgIV = optionChain.length > 0
      ? optionChain.reduce((sum, o) => sum + (o.ce.impliedVolatility + o.pe.impliedVolatility) / 2, 0) / optionChain.length
      : 15;
    return calculateTotalStrategyGreeks(
      strategy.legs.map(l => ({ type: l.type, action: l.action, strikePrice: l.strikePrice })),
      spotPrice,
      daysToExpiry / 365,
      avgIV / 100,
      riskFreeRate / 100,
    );
  }, [strategy, spotPrice, optionChain, daysToExpiry, riskFreeRate]);

  const greekBar = (value: number, maxAbsValue: number = 1): string => {
    const absValue = Math.abs(value);
    const pct = Math.min(100, (absValue / maxAbsValue) * 50);
    return `${pct}%`;
  };

  const renderGreek = (label: string, value: number, color: string, description: string) => (
    <div className="bg-slate-800/40 rounded-xl p-3">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[11px] font-semibold text-slate-300">{label}</span>
        <span className="text-[10px] text-slate-500">{description}</span>
      </div>
      <p className={`text-lg font-bold tabular-nums ${value >= 0 ? color : 'text-red-400'}`}>
        {value.toFixed(4)}
      </p>
      <div className="mt-1.5 h-1 bg-slate-700 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${value >= 0 ? color.replace('text-', 'bg-') : 'bg-red-500'}`}
          style={{ width: greekBar(value, 1) }}
        />
      </div>
    </div>
  );

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5 space-y-5">
      <h2 className="text-base font-semibold text-white flex items-center gap-2">
        <svg className="w-5 h-5 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.399 5.84c-.896.248-1.783.52-2.658.814m-15.482 0A50.697 50.697 0 0112 13.489a50.702 50.702 0 017.74-3.342M6.75 15a.75.75 0 100-1.5.75.75 0 000 1.5zm0 0v-3.675A55.378 55.378 0 0112 8.443m-7.007 11.55A5.981 5.981 0 006.75 15.75v-1.5" />
        </svg>
        Greeks Calculator
      </h2>

      {/* Input Controls */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div>
          <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Strike</label>
          <input
            type="number"
            value={customStrike}
            onChange={(e) => setCustomStrike(Number(e.target.value))}
            className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 tabular-nums"
          />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Type</label>
          <div className="flex rounded-lg overflow-hidden border border-slate-700">
            <button
              onClick={() => setCustomType('CE')}
              className={`flex-1 py-2 text-xs font-semibold transition-colors ${customType === 'CE' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400'}`}
            >CE</button>
            <button
              onClick={() => setCustomType('PE')}
              className={`flex-1 py-2 text-xs font-semibold transition-colors ${customType === 'PE' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'}`}
            >PE</button>
          </div>
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">IV%</label>
          <input
            type="number"
            value={customIV}
            onChange={(e) => setCustomIV(Number(e.target.value))}
            className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 tabular-nums"
            step="0.1"
            min="1"
            max="100"
          />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">Days to Expiry</label>
          <input
            type="number"
            value={daysToExpiry}
            onChange={(e) => setDaysToExpiry(Number(e.target.value))}
            className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 tabular-nums"
            min="1"
            max="365"
          />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">RFR%</label>
          <input
            type="number"
            value={riskFreeRate}
            onChange={(e) => setRiskFreeRate(Number(e.target.value))}
            className="w-full bg-slate-800 text-white text-sm rounded-lg px-3 py-2 border border-slate-700 tabular-nums"
            step="0.1"
          />
        </div>
      </div>

      {/* Single Option Greeks */}
      <div>
        <p className="text-[11px] text-slate-500 uppercase tracking-wider mb-3">
          {customType} {customStrike} Greeks (Spot: {spotPrice.toFixed(2)})
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {renderGreek('Δ Delta', customGreeks.delta, 'text-blue-400', 'Price sensitivity')}
          {renderGreek('Γ Gamma', customGreeks.gamma, 'text-purple-400', 'Delta change')}
          {renderGreek('Θ Theta', customGreeks.theta, 'text-orange-400', 'Time decay/day')}
          {renderGreek('ν Vega', customGreeks.vega, 'text-cyan-400', 'IV sensitivity')}
          {renderGreek('Ρ Rho', customGreeks.rho, 'text-pink-400', 'Rate sensitivity')}
        </div>
      </div>

      {/* Strategy Greeks */}
      {strategyGreeks && (
        <div className="pt-4 border-t border-slate-700/50">
          <p className="text-[11px] text-slate-500 uppercase tracking-wider mb-3">
            Strategy: {strategy.name}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {renderGreek('Δ Delta', strategyGreeks.delta, 'text-blue-400', 'Directional')}
            {renderGreek('Γ Gamma', strategyGreeks.gamma, 'text-purple-400', 'Convexity')}
            {renderGreek('Θ Theta', strategyGreeks.theta, 'text-orange-400', 'Time decay/day')}
            {renderGreek('ν Vega', strategyGreeks.vega, 'text-cyan-400', 'Vol sensitivity')}
            {renderGreek('Ρ Rho', strategyGreeks.rho, 'text-pink-400', 'Rate sensitivity')}
          </div>
        </div>
      )}
    </div>
  );
}
