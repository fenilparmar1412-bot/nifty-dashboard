import { useMemo } from 'react';
import { OptionData } from '../types';
import {
  calculatePCR,
  interpretPCR,
  calculateMaxPain,
} from '../utils/technicalIndicators';
import { formatIndianNumber } from '../utils/optionCalculations';

interface MarketAnalysisProps {
  optionChain: OptionData[];
  spotPrice: number;
}

export default function MarketAnalysis({ optionChain, spotPrice }: MarketAnalysisProps) {
  const pcr = useMemo(() => calculatePCR(optionChain), [optionChain]);
  const pcrInterpretation = useMemo(() => interpretPCR(pcr), [pcr]);
  const maxPain = useMemo(() => calculateMaxPain(optionChain), [optionChain]);
  const maxPainDiff = maxPain - spotPrice;

  // Most active strikes by OI
  const mostActive = useMemo(() => {
    if (optionChain.length === 0) return [];
    return [...optionChain]
      .sort((a, b) => (b.ce.openInterest + b.pe.openInterest) - (a.ce.openInterest + a.pe.openInterest))
      .slice(0, 8);
  }, [optionChain]);

  // OI Spurt — strikes with biggest change in OI
  const oiSpurt = useMemo(() => {
    if (optionChain.length === 0) return [];
    return [...optionChain]
      .map(row => ({
        ...row,
        totalChange: Math.abs(row.ce.changeInOI) + Math.abs(row.pe.changeInOI),
      }))
      .sort((a, b) => b.totalChange - a.totalChange)
      .slice(0, 6);
  }, [optionChain]);

  // Call/Put writers analysis
  const writersAnalysis = useMemo(() => {
    let callWriters = 0;
    let putWriters = 0;
    let callUnwinding = 0;
    let putUnwinding = 0;

    optionChain.forEach(row => {
      // Call writing: OI up + Price down
      if (row.ce.changeInOI > 0 && row.ce.change < 0) callWriters += row.ce.changeInOI;
      // Put writing: OI up + Price down
      if (row.pe.changeInOI > 0 && row.pe.change < 0) putWriters += row.pe.changeInOI;
      // Call unwinding: OI down + Price up
      if (row.ce.changeInOI < 0 && row.ce.change > 0) callUnwinding += Math.abs(row.ce.changeInOI);
      // Put unwinding: OI down + Price up
      if (row.pe.changeInOI < 0 && row.pe.change > 0) putUnwinding += Math.abs(row.pe.changeInOI);
    });

    return { callWriters, putWriters, callUnwinding, putUnwinding };
  }, [optionChain]);

  // Strike liquidity score (0-100)
  const getLiquidityScore = (row: OptionData): number => {
    const oiScore = Math.min(50, (row.ce.openInterest + row.pe.openInterest) / 100000);
    const volScore = Math.min(30, (row.ce.volume + row.pe.volume) / 5000);
    const spreadScore = (() => {
      const ceSpread = row.ce.ask - row.ce.bid;
      const peSpread = row.pe.ask - row.pe.bid;
      const avgSpread = (ceSpread + peSpread) / 2;
      const avgPrice = (row.ce.lastPrice + row.pe.lastPrice) / 2;
      if (avgPrice === 0) return 0;
      const spreadPct = (avgSpread / avgPrice) * 100;
      return Math.max(0, 20 - spreadPct * 2);
    })();
    return Math.round(oiScore + volScore + spreadScore);
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <h2 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
        <svg className="w-5 h-5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
        Market Analysis
      </h2>

      {/* Top Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {/* PCR */}
        <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/25 rounded-xl p-4">
          <div className="flex items-center justify-between mb-1">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">PCR (OI)</p>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Put/Call</span>
          </div>
          <p className={`text-2xl font-bold tabular-nums ${pcrInterpretation.color}`}>
            {pcr.toFixed(3)}
          </p>
          <p className={`text-[10px] font-semibold mt-1 ${pcrInterpretation.color}`}>
            {pcrInterpretation.signal}
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">{pcrInterpretation.message}</p>
        </div>

        {/* Max Pain */}
        <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/25 rounded-xl p-4">
          <div className="flex items-center justify-between mb-1">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Max Pain</p>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Expiry Target</span>
          </div>
          <p className="text-2xl font-bold text-orange-400 tabular-nums">
            {maxPain.toLocaleString('en-IN')}
          </p>
          <p className={`text-[10px] font-semibold mt-1 tabular-nums ${maxPainDiff >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
            {maxPainDiff >= 0 ? '↑' : '↓'} {Math.abs(maxPainDiff).toFixed(2)} from spot
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {maxPainDiff > 0 ? 'Market may rise to Max Pain' : maxPainDiff < 0 ? 'Market may fall to Max Pain' : 'Spot = Max Pain'}
          </p>
        </div>

        {/* Call Writers */}
        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/25 rounded-xl p-4">
          <div className="flex items-center justify-between mb-1">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Call Writing</p>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Resistance</span>
          </div>
          <p className="text-2xl font-bold text-amber-400 tabular-nums">
            {formatIndianNumber(writersAnalysis.callWriters)}
          </p>
          <p className="text-[10px] text-slate-500 mt-1">
            Unwinding: <span className="text-emerald-400">{formatIndianNumber(writersAnalysis.callUnwinding)}</span>
          </p>
        </div>

        {/* Put Writers */}
        <div className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/25 rounded-xl p-4">
          <div className="flex items-center justify-between mb-1">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Put Writing</p>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">Support</span>
          </div>
          <p className="text-2xl font-bold text-emerald-400 tabular-nums">
            {formatIndianNumber(writersAnalysis.putWriters)}
          </p>
          <p className="text-[10px] text-slate-500 mt-1">
            Unwinding: <span className="text-red-400">{formatIndianNumber(writersAnalysis.putUnwinding)}</span>
          </p>
        </div>
      </div>

      {/* Most Active Strikes & OI Spurt */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Most Active Strikes */}
        <div>
          <h3 className="text-xs font-semibold text-white mb-2 flex items-center gap-2">
            🔥 Most Active Strikes (by OI)
            <span className="text-[10px] text-slate-500 font-normal">— Best liquidity for trading</span>
          </h3>
          <div className="space-y-1">
            {mostActive.map((row, i) => {
              const score = getLiquidityScore(row);
              const isATM = Math.abs(row.strikePrice - spotPrice) < 50;
              return (
                <div key={row.strikePrice} className={`flex items-center gap-2 p-2 rounded-lg text-xs ${
                  isATM ? 'bg-amber-500/10 border border-amber-500/25' : 'bg-slate-800/40'
                }`}>
                  <span className="w-5 text-slate-500 font-mono">#{i + 1}</span>
                  <div className="flex items-center gap-1.5 flex-1">
                    <span className={`font-bold tabular-nums ${isATM ? 'text-amber-400' : 'text-white'}`}>
                      {row.strikePrice.toLocaleString('en-IN')}
                    </span>
                    {isATM && <span className="text-[9px] px-1 py-0.5 rounded bg-amber-500/25 text-amber-400 font-bold">ATM</span>}
                  </div>
                  <div className="flex items-center gap-3 text-[10px]">
                    <div className="text-slate-400">
                      OI: <span className="text-white tabular-nums">{formatIndianNumber(row.ce.openInterest + row.pe.openInterest)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            score >= 80 ? 'bg-emerald-500' :
                            score >= 60 ? 'bg-cyan-500' :
                            score >= 40 ? 'bg-amber-500' :
                            'bg-red-500'
                          }`}
                          style={{ width: `${score}%` }}
                        />
                      </div>
                      <span className={`tabular-nums w-6 text-right ${
                        score >= 80 ? 'text-emerald-400' :
                        score >= 60 ? 'text-cyan-400' :
                        score >= 40 ? 'text-amber-400' :
                        'text-red-400'
                      }`}>
                        {score}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <p className="text-[10px] text-slate-500 mt-2">
            💡 Liquidity Score (0-100): Higher = easier to trade, tighter bid-ask spread
          </p>
        </div>

        {/* OI Spurt */}
        <div>
          <h3 className="text-xs font-semibold text-white mb-2 flex items-center gap-2">
            ⚡ OI Spurt (Biggest Change in OI)
            <span className="text-[10px] text-slate-500 font-normal">— Fresh positions being built</span>
          </h3>
          <div className="space-y-1">
            {oiSpurt.map((row, i) => {
              const ceBullish = row.ce.changeInOI > 0; // CE writing (bearish)
              const peBullish = row.pe.changeInOI > 0; // PE writing (bullish)
              return (
                <div key={row.strikePrice} className="flex items-center gap-2 p-2 rounded-lg bg-slate-800/40 text-xs">
                  <span className="w-5 text-slate-500 font-mono">#{i + 1}</span>
                  <span className="font-bold text-white tabular-nums w-20">
                    {row.strikePrice.toLocaleString('en-IN')}
                  </span>
                  <div className="flex items-center gap-2 flex-1 text-[10px]">
                    <div className="flex items-center gap-1">
                      <span className={`font-semibold tabular-nums ${ceBullish ? 'text-red-400' : 'text-emerald-400'}`}>
                        CE: {ceBullish ? '+' : ''}{formatIndianNumber(row.ce.changeInOI)}
                      </span>
                    </div>
                    <span className="text-slate-600">|</span>
                    <div className="flex items-center gap-1">
                      <span className={`font-semibold tabular-nums ${peBullish ? 'text-emerald-400' : 'text-red-400'}`}>
                        PE: {peBullish ? '+' : ''}{formatIndianNumber(row.pe.changeInOI)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3 p-3 bg-slate-800/30 rounded-lg text-[10px] text-slate-400 space-y-1">
            <p><span className="text-red-400 font-bold">+CE OI</span> = Call writing → Resistance building (bearish)</p>
            <p><span className="text-emerald-400 font-bold">+PE OI</span> = Put writing → Support building (bullish)</p>
            <p><span className="text-emerald-400 font-bold">-CE OI</span> = Call unwinding → Resistance broken (bullish)</p>
            <p><span className="text-red-400 font-bold">-PE OI</span> = Put unwinding → Support broken (bearish)</p>
          </div>
        </div>
      </div>
    </div>
  );
}
