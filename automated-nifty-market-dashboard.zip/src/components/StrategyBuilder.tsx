import { useState, useMemo } from 'react';
import { Strategy, StrategyLeg, OptionData } from '../types';
import { formatCurrency } from '../utils/optionCalculations';

const PRESET_STRATEGIES: { name: string; id: string; description: string }[] = [
  { id: 'bullish', name: 'Bullish Call', description: 'Buy 1 ATM CE' },
  { id: 'bearish', name: 'Bearish Put', description: 'Buy 1 ATM PE' },
  { id: 'straddle', name: 'Long Straddle', description: 'Buy ATM CE + PE' },
  { id: 'strangle', name: 'Long Strangle', description: 'Buy OTM CE + OTM PE' },
  { id: 'covered_call', name: 'Covered Call', description: 'Sell 1 OTM CE' },
  { id: 'iron_condor', name: 'Iron Condor', description: 'Sell OTM CE+PE, Buy far OTM' },
  { id: 'butterfly', name: 'Butterfly Spread', description: '1-2-1 Strike combo' },
  { id: 'bull_spread', name: 'Bull Call Spread', description: 'Buy ATM CE + Sell OTM CE' },
];

interface StrategyBuilderProps {
  strategy: Strategy;
  onUpdateStrategy: (strategy: Strategy) => void;
  spotPrice: number;
  optionChain: OptionData[];
  lotSize?: number;
}

export default function StrategyBuilder({ strategy, onUpdateStrategy, spotPrice, optionChain, lotSize = 50 }: StrategyBuilderProps) {
  const [selectedPreset, setSelectedPreset] = useState<string>('');

  const atmStrike = useMemo(() => {
    if (!optionChain.length) return Math.round(spotPrice / 50) * 50;
    return optionChain.reduce((prev, curr) =>
      Math.abs(curr.strikePrice - spotPrice) < Math.abs(prev.strikePrice - spotPrice) ? curr : prev
    ).strikePrice;
  }, [optionChain, spotPrice]);

  const applyPreset = (presetId: string) => {
    setSelectedPreset(presetId);
    const nextStrikeUp = atmStrike + 100;
    const nextStrikeDown = atmStrike - 100;
    const farStrikeUp = atmStrike + 200;
    const farStrikeDown = atmStrike - 200;

    const findPremium = (strike: number, type: 'CE' | 'PE'): number => {
      const row = optionChain.find(o => o.strikePrice === strike);
      if (!row) return 50;
      return type === 'CE' ? row.ce.ask : row.pe.ask;
    };

    let legs: StrategyLeg[] = [];

    const qty = lotSize;
    switch (presetId) {
      case 'bullish':
        legs = [{ type: 'CE', action: 'BUY', strikePrice: atmStrike, premium: findPremium(atmStrike, 'CE'), quantity: qty }];
        break;
      case 'bearish':
        legs = [{ type: 'PE', action: 'BUY', strikePrice: atmStrike, premium: findPremium(atmStrike, 'PE'), quantity: qty }];
        break;
      case 'straddle':
        legs = [
          { type: 'CE', action: 'BUY', strikePrice: atmStrike, premium: findPremium(atmStrike, 'CE'), quantity: qty },
          { type: 'PE', action: 'BUY', strikePrice: atmStrike, premium: findPremium(atmStrike, 'PE'), quantity: qty },
        ];
        break;
      case 'strangle':
        legs = [
          { type: 'CE', action: 'BUY', strikePrice: nextStrikeUp, premium: findPremium(nextStrikeUp, 'CE'), quantity: qty },
          { type: 'PE', action: 'BUY', strikePrice: nextStrikeDown, premium: findPremium(nextStrikeDown, 'PE'), quantity: qty },
        ];
        break;
      case 'covered_call':
        legs = [{ type: 'CE', action: 'SELL', strikePrice: nextStrikeUp, premium: findPremium(nextStrikeUp, 'CE'), quantity: qty }];
        break;
      case 'iron_condor':
        legs = [
          { type: 'CE', action: 'SELL', strikePrice: nextStrikeUp, premium: findPremium(nextStrikeUp, 'CE'), quantity: qty },
          { type: 'CE', action: 'BUY', strikePrice: farStrikeUp, premium: findPremium(farStrikeUp, 'CE'), quantity: qty },
          { type: 'PE', action: 'SELL', strikePrice: nextStrikeDown, premium: findPremium(nextStrikeDown, 'PE'), quantity: qty },
          { type: 'PE', action: 'BUY', strikePrice: farStrikeDown, premium: findPremium(farStrikeDown, 'PE'), quantity: qty },
        ];
        break;
      case 'butterfly':
        legs = [
          { type: 'CE', action: 'BUY', strikePrice: atmStrike - 100, premium: findPremium(atmStrike - 100, 'CE'), quantity: qty },
          { type: 'CE', action: 'SELL', strikePrice: atmStrike, premium: findPremium(atmStrike, 'CE'), quantity: qty * 2 },
          { type: 'CE', action: 'BUY', strikePrice: atmStrike + 100, premium: findPremium(atmStrike + 100, 'CE'), quantity: qty },
        ];
        break;
      case 'bull_spread':
        legs = [
          { type: 'CE', action: 'BUY', strikePrice: atmStrike, premium: findPremium(atmStrike, 'CE'), quantity: qty },
          { type: 'CE', action: 'SELL', strikePrice: nextStrikeUp, premium: findPremium(nextStrikeUp, 'CE'), quantity: qty },
        ];
        break;
    }

    onUpdateStrategy({
      id: presetId,
      name: PRESET_STRATEGIES.find(p => p.id === presetId)?.name || '',
      legs,
    });
  };

  const addLeg = (type: 'CE' | 'PE', action: 'BUY' | 'SELL') => {
    const defaultStrike = atmStrike;
    const premium = 50;
    onUpdateStrategy({
      ...strategy,
      id: 'custom',
      name: 'Custom Strategy',
      legs: [...strategy.legs, { type, action, strikePrice: defaultStrike, premium, quantity: lotSize }],
    });
  };

  const removeLeg = (index: number) => {
    const newLegs = strategy.legs.filter((_, i) => i !== index);
    onUpdateStrategy({ ...strategy, legs: newLegs });
  };

  const updateLeg = (index: number, updates: Partial<StrategyLeg>) => {
    const newLegs = strategy.legs.map((leg, i) =>
      i === index ? { ...leg, ...updates } : leg
    );
    onUpdateStrategy({ ...strategy, legs: newLegs });
  };

  const totalPremium = strategy.legs.reduce((sum, leg) => {
    return sum + (leg.action === 'BUY' ? -leg.premium : leg.premium) * leg.quantity;
  }, 0);

  const maxProfit = useMemo(() => {
    let max = -Infinity;
    for (let price = spotPrice * 0.8; price <= spotPrice * 1.2; price += 10) {
      let pnl = 0;
      strategy.legs.forEach(leg => {
        let iv = 0;
        if (leg.type === 'CE') iv = Math.max(0, price - leg.strikePrice);
        else iv = Math.max(0, leg.strikePrice - price);
        pnl += (iv - leg.premium) * leg.quantity * (leg.action === 'BUY' ? 1 : -1);
      });
      if (pnl > max) max = pnl;
    }
    return max;
  }, [strategy, spotPrice]);

  const maxLoss = useMemo(() => {
    let min = Infinity;
    for (let price = spotPrice * 0.8; price <= spotPrice * 1.2; price += 10) {
      let pnl = 0;
      strategy.legs.forEach(leg => {
        let iv = 0;
        if (leg.type === 'CE') iv = Math.max(0, price - leg.strikePrice);
        else iv = Math.max(0, leg.strikePrice - price);
        pnl += (iv - leg.premium) * leg.quantity * (leg.action === 'BUY' ? 1 : -1);
      });
      if (pnl < min) min = pnl;
    }
    return min;
  }, [strategy, spotPrice]);

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-2xl border border-slate-700/50 p-5">
      <h2 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
        <svg className="w-5 h-5 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
        Strategy Builder
      </h2>

      {/* Preset Strategies */}
      <div className="mb-4">
        <p className="text-[11px] text-slate-500 uppercase tracking-wider mb-2">Quick Presets</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {PRESET_STRATEGIES.map(p => (
            <button
              key={p.id}
              onClick={() => applyPreset(p.id)}
              className={`px-3 py-2 rounded-lg text-left text-xs transition-all ${
                selectedPreset === p.id
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              <div className="font-semibold">{p.name}</div>
              <div className="text-[10px] opacity-70 mt-0.5">{p.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Manual Add Buttons */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-[11px] text-slate-500 uppercase tracking-wider">Add Leg:</span>
        <button onClick={() => addLeg('CE', 'BUY')} className="px-3 py-1.5 text-xs rounded-lg bg-emerald-600/15 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-600/25 transition-colors">Buy CE</button>
        <button onClick={() => addLeg('CE', 'SELL')} className="px-3 py-1.5 text-xs rounded-lg bg-red-600/15 text-red-400 hover:bg-red-600/30 border border-red-600/25 transition-colors">Sell CE</button>
        <button onClick={() => addLeg('PE', 'BUY')} className="px-3 py-1.5 text-xs rounded-lg bg-emerald-600/15 text-emerald-400 hover:bg-emerald-600/30 border border-emerald-600/25 transition-colors">Buy PE</button>
        <button onClick={() => addLeg('PE', 'SELL')} className="px-3 py-1.5 text-xs rounded-lg bg-red-600/15 text-red-400 hover:bg-red-600/30 border border-red-600/25 transition-colors">Sell PE</button>
      </div>

      {/* Legs Table */}
      {strategy.legs.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left py-2 px-2 text-slate-500 font-medium">#</th>
                <th className="text-left py-2 px-2 text-slate-500 font-medium">Type</th>
                <th className="text-left py-2 px-2 text-slate-500 font-medium">Action</th>
                <th className="text-right py-2 px-2 text-slate-500 font-medium">Strike</th>
                <th className="text-right py-2 px-2 text-slate-500 font-medium">Premium</th>
                <th className="text-right py-2 px-2 text-slate-500 font-medium">Qty</th>
                <th className="text-right py-2 px-2 text-slate-500 font-medium">Total</th>
                <th className="text-center py-2 px-2 text-slate-500 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {strategy.legs.map((leg, i) => (
                <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/20">
                  <td className="py-2 px-2 text-slate-600">{i + 1}</td>
                  <td className="py-2 px-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${leg.type === 'CE' ? 'bg-amber-500/15 text-amber-400' : 'bg-emerald-500/15 text-emerald-400'}`}>
                      {leg.type}
                    </span>
                  </td>
                  <td className="py-2 px-2">
                    <select
                      value={leg.action}
                      onChange={(e) => updateLeg(i, { action: e.target.value as 'BUY' | 'SELL' })}
                      className="bg-slate-800 text-slate-300 text-xs rounded px-2 py-1 border border-slate-700"
                    >
                      <option value="BUY">BUY</option>
                      <option value="SELL">SELL</option>
                    </select>
                  </td>
                  <td className="py-2 px-2 text-right">
                    <input
                      type="number"
                      value={leg.strikePrice}
                      onChange={(e) => updateLeg(i, { strikePrice: Number(e.target.value) })}
                      className="w-24 bg-slate-800 text-white text-xs rounded px-2 py-1 text-right border border-slate-700 tabular-nums"
                    />
                  </td>
                  <td className="py-2 px-2 text-right">
                    <input
                      type="number"
                      value={leg.premium}
                      onChange={(e) => updateLeg(i, { premium: Number(e.target.value) })}
                      className="w-20 bg-slate-800 text-white text-xs rounded px-2 py-1 text-right border border-slate-700 tabular-nums"
                      step="0.5"
                    />
                  </td>
                  <td className="py-2 px-2 text-right">
                    <input
                      type="number"
                      value={leg.quantity}
                      onChange={(e) => updateLeg(i, { quantity: Number(e.target.value) })}
                      className="w-16 bg-slate-800 text-white text-xs rounded px-2 py-1 text-right border border-slate-700 tabular-nums"
                      step="25"
                    />
                  </td>
                  <td className={`py-2 px-2 text-right font-semibold tabular-nums ${leg.action === 'SELL' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {leg.action === 'SELL' ? '+' : '-'}{formatCurrency(leg.premium * leg.quantity)}
                  </td>
                  <td className="py-2 px-2 text-center">
                    <button onClick={() => removeLeg(i)} className="text-red-400 hover:text-red-300 p-1">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Summary */}
      {strategy.legs.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-700/50">
          <div className="bg-slate-800/50 rounded-xl p-3">
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Total Premium</p>
            <p className={`text-base font-bold tabular-nums ${totalPremium >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {formatCurrency(totalPremium)}
            </p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-3">
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Max Profit</p>
            <p className="text-base font-bold text-emerald-400 tabular-nums">{formatCurrency(maxProfit)}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-3">
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Max Loss</p>
            <p className="text-base font-bold text-red-400 tabular-nums">{formatCurrency(maxLoss)}</p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-3">
            <p className="text-[10px] text-slate-500 uppercase tracking-wider">Spot: {spotPrice.toFixed(2)}</p>
            <p className={`text-base font-bold tabular-nums ${strategy.legs.length > 0 ? 'text-indigo-400' : 'text-slate-500'}`}>
              {strategy.legs.length} Leg{strategy.legs.length > 1 ? 's' : ''}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
