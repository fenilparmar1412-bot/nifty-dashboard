import { useState, useEffect, useCallback, useRef } from 'react';
import { OptionChainResponse, OptionData } from '../types';
import { getMarketStatus, shouldRefreshData } from '../utils/marketHours';
import { SymbolConfig, getSymbolConfig } from '../utils/symbols';
import { generatePriceHistory } from '../utils/technicalIndicators';

function generateSimulatedOptionChain(
  spotPrice: number,
  config: SymbolConfig,
  frozen: boolean
): OptionData[] {
  const data: OptionData[] = [];
  const stride = config.strikeStride;
  const baseStrike = Math.round(spotPrice / stride) * stride;

  // More strikes: 40 on each side (total 80 strikes)
  const strikesPerSide = 40;

  for (let i = -strikesPerSide; i <= strikesPerSide; i++) {
    const strike = baseStrike + i * stride;
    if (strike <= 0) continue;

    const distanceFromSpot = (strike - spotPrice) / spotPrice;
    const baseIV = (config.avgIV / 100) + (Math.random() * 0.04 - 0.02);

    // Liquidity decreases as we move away from ATM
    const liquidityFactor = Math.exp(-Math.abs(i) * 0.08);

    // CE
    const ceIntrinsic = Math.max(0, spotPrice - strike);
    const ceTimeValue = spotPrice * 0.015 * Math.exp(-Math.abs(distanceFromSpot) * 12);
    const ceTheoretical = ceIntrinsic + ceTimeValue;
    const noiseFactor = frozen ? 1.0 : (0.97 + Math.random() * 0.06);
    const cePrice = Math.max(0.05, ceTheoretical * noiseFactor);

    // PE
    const peIntrinsic = Math.max(0, strike - spotPrice);
    const peTimeValue = spotPrice * 0.015 * Math.exp(-Math.abs(distanceFromSpot) * 12);
    const peTheoretical = peIntrinsic + peTimeValue;
    const pePrice = Math.max(0.05, peTheoretical * noiseFactor);

    const changeMultiplier = frozen ? 0 : 1;

    // OI pattern: higher near ATM, with some random spikes (representing real liquidity)
    const baseOI = 5000000 * liquidityFactor;
    const oiSpike = Math.random() > 0.85 ? (1 + Math.random() * 3) : 1; // 15% strikes get high OI spike

    data.push({
      strikePrice: strike,
      expiryDate: getNextThursday(),
      ce: {
        openInterest: Math.floor(baseOI * oiSpike * (0.8 + Math.random() * 0.4)),
        changeInOI: Math.floor((Math.random() - 0.5) * baseOI * 0.15 * changeMultiplier),
        volume: frozen ? 0 : Math.floor(baseOI * 0.05 * liquidityFactor * (0.5 + Math.random())),
        lastPrice: Math.round(cePrice * 100) / 100,
        change: Math.round((Math.random() - 0.5) * cePrice * 0.3 * 100 * changeMultiplier) / 100,
        bid: Math.round((cePrice * (1 - 0.005 * (1 - liquidityFactor))) * 100) / 100,
        ask: Math.round((cePrice * (1 + 0.005 * (1 - liquidityFactor))) * 100) / 100,
        impliedVolatility: Math.round(baseIV * 10000) / 100,
      },
      pe: {
        openInterest: Math.floor(baseOI * (Math.random() > 0.85 ? oiSpike : 1) * (0.8 + Math.random() * 0.4)),
        changeInOI: Math.floor((Math.random() - 0.5) * baseOI * 0.15 * changeMultiplier),
        volume: frozen ? 0 : Math.floor(baseOI * 0.05 * liquidityFactor * (0.5 + Math.random())),
        lastPrice: Math.round(pePrice * 100) / 100,
        change: Math.round((Math.random() - 0.5) * pePrice * 0.3 * 100 * changeMultiplier) / 100,
        bid: Math.round((pePrice * (1 - 0.005 * (1 - liquidityFactor))) * 100) / 100,
        ask: Math.round((pePrice * (1 + 0.005 * (1 - liquidityFactor))) * 100) / 100,
        impliedVolatility: Math.round(baseIV * 10000) / 100,
      },
    });
  }
  return data;
}

function getNextThursday(): string {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const daysUntilThursday = dayOfWeek <= 4 ? 4 - dayOfWeek : 11 - dayOfWeek;
  const thursday = new Date(now);
  thursday.setDate(now.getDate() + (daysUntilThursday === 0 ? 7 : daysUntilThursday));
  return thursday.toISOString().split('T')[0];
}

function generateExpiryDates(): string[] {
  const dates: string[] = [];
  const now = new Date();
  for (let i = 0; i < 4; i++) {
    const d = new Date(now);
    const daysUntilThursday = (4 - d.getDay() + 7) % 7 || 7;
    d.setDate(now.getDate() + daysUntilThursday + (i * 7));
    dates.push(d.toISOString().split('T')[0]);
  }
  return dates;
}

function getDailySeed(symbol: string): number {
  const today = new Date();
  const dateStr = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}-${symbol}`;
  let hash = 0;
  for (let i = 0; i < dateStr.length; i++) {
    hash = ((hash << 5) - hash) + dateStr.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

// Yahoo Finance symbols for real data
const YAHOO_SYMBOLS: Record<string, string> = {
  NIFTY: '^NSEI',
  BANKNIFTY: '^NSEBANK',
  FINNIFTY: '^CNXFIN',
  MIDCPNIFTY: '^NSEMDCP50',
  SENSEX: '^BSESN',
};

async function fetchRealYahooData(config: SymbolConfig): Promise<{
  spotPrice: number;
  lastClose: number;
  dayHigh: number;
  dayLow: number;
  change: number;
  changePercent: number;
  source: 'YAHOO';
} | null> {
  const yahooSymbol = YAHOO_SYMBOLS[config.symbol];
  if (!yahooSymbol) return null;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    // Try multiple CORS-friendly endpoints
    const endpoints = [
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol)}?interval=1d&range=1d`,
      `https://query2.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSymbol)}?interval=1d&range=1d`,
    ];

    for (const url of endpoints) {
      try {
        const response = await fetch(url, {
          signal: controller.signal,
          headers: { 'Accept': 'application/json' },
        });

        if (!response.ok) continue;

        const data = await response.json();
        const result = data?.chart?.result?.[0];
        const meta = result?.meta;

        if (meta?.regularMarketPrice) {
          clearTimeout(timeoutId);
          const spotPrice = meta.regularMarketPrice;
          const lastClose = meta.chartPreviousClose || meta.previousClose || spotPrice;
          const change = spotPrice - lastClose;
          const changePercent = (change / lastClose) * 100;

          // Try to get day high/low from indicators
          const quotes = result?.indicators?.quote?.[0];
          const dayHigh = quotes?.high?.[quotes.high.length - 1] || spotPrice * 1.005;
          const dayLow = quotes?.low?.[quotes.low.length - 1] || spotPrice * 0.995;

          return { spotPrice, lastClose, dayHigh, dayLow, change, changePercent, source: 'YAHOO' as const };
        }
      } catch {
        continue;
      }
    }
    clearTimeout(timeoutId);
  } catch {
    return null;
  }
  return null;
}

async function fetchRealData(config: SymbolConfig): Promise<{
  spotPrice: number;
  lastClose: number;
  dayHigh: number;
  dayLow: number;
  change: number;
  changePercent: number;
  source: 'YAHOO' | 'NSE';
} | null> {
  // Try Yahoo Finance first (more reliable, no CORS issues)
  const yahooData = await fetchRealYahooData(config);
  if (yahooData) return yahooData;

  // Fall back to NSE API (may be blocked by CORS)
  if (!config.nseApiSymbol || config.type !== 'INDEX') return null;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(
      `https://www.nseindia.com/api/option-chain-indices?symbol=${config.nseApiSymbol}`,
      {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'Accept': 'application/json',
        },
      }
    );
    clearTimeout(timeoutId);

    if (response.ok) {
      const raw = await response.json();
      const spotPrice = raw.records?.underlyingValue || config.basePrice;
      const change = raw.records?.underlyingChange || 0;

      return {
        spotPrice,
        lastClose: spotPrice - change,
        change,
        changePercent: (change / spotPrice) * 100,
        dayHigh: spotPrice + Math.abs(change) * 2,
        dayLow: spotPrice - Math.abs(change) * 2,
        source: 'NSE' as const,
      };
    }
  } catch {
    return null;
  }
  return null;
}

function fetchNiftyData(config: SymbolConfig): OptionChainResponse {
  const marketStatus = getMarketStatus();
  const frozen = !marketStatus.isOpen;

  const seed = getDailySeed(config.symbol);
  const pseudoRandom = (offset: number) => {
    const x = Math.sin(seed + offset) * 10000;
    return x - Math.floor(x);
  };

  let spotPrice: number;
  let lastClose: number;

  if (frozen) {
    lastClose = config.basePrice * (0.98 + pseudoRandom(1) * 0.04);
    const dailyChange = (pseudoRandom(2) - 0.5) * config.basePrice * 0.02;
    spotPrice = lastClose + dailyChange;
  } else {
    spotPrice = config.basePrice * (1 + (Math.random() - 0.5) * 0.02);
    lastClose = spotPrice - (Math.random() - 0.5) * config.basePrice * 0.01;
  }

  const change = spotPrice - lastClose;

  return {
    spotPrice: Math.round(spotPrice * 100) / 100,
    lastClose: Math.round(lastClose * 100) / 100,
    change: Math.round(change * 100) / 100,
    changePercent: Math.round((change / lastClose) * 10000) / 100,
    dayHigh: Math.round((spotPrice + pseudoRandom(3) * config.basePrice * 0.008) * 100) / 100,
    dayLow: Math.round((spotPrice - pseudoRandom(4) * config.basePrice * 0.008) * 100) / 100,
    data: generateSimulatedOptionChain(spotPrice, config, frozen),
    expiryDates: generateExpiryDates(),
  };
}

export function useNiftyData(symbol: string = 'NIFTY', refreshIntervalMs: number = 3000) {
  const config = getSymbolConfig(symbol);

  const [data, setData] = useState<OptionChainResponse | null>(null);
  const [priceHistory, setPriceHistory] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [marketStatus, setMarketStatus] = useState(getMarketStatus());
  const [dataSource, setDataSource] = useState<'YAHOO' | 'NSE' | 'SIMULATED'>('SIMULATED');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchData = useCallback(async () => {
    setMarketStatus(getMarketStatus());

    if (!shouldRefreshData() && data !== null) {
      return;
    }

    try {
      // Try real spot price from Yahoo Finance first
      const realSpotData = await fetchRealData(config);

      let result: OptionChainResponse;

      if (realSpotData) {
        // Use real spot price + generate option chain
        const marketStatus = getMarketStatus();
        const frozen = !marketStatus.isOpen;
        setDataSource(realSpotData.source);

        result = {
          spotPrice: realSpotData.spotPrice,
          lastClose: realSpotData.lastClose,
          change: realSpotData.change,
          changePercent: realSpotData.changePercent,
          dayHigh: realSpotData.dayHigh,
          dayLow: realSpotData.dayLow,
          data: generateSimulatedOptionChain(realSpotData.spotPrice, config, frozen),
          expiryDates: generateExpiryDates(),
        };
      } else {
        // Fall back to full simulation
        setDataSource('SIMULATED');
        result = fetchNiftyData(config);
      }

      setData(result);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, [config, data]);

  // Initialize price history for RSI calculation
  useEffect(() => {
    const history = generatePriceHistory(config.basePrice, 100, 0.015);
    setPriceHistory(history);
  }, [config.basePrice]);

  // Update price history as spot price changes
  useEffect(() => {
    if (data && priceHistory.length > 0) {
      const newHistory = [...priceHistory.slice(1), data.spotPrice];
      setPriceHistory(newHistory);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.spotPrice]);

  useEffect(() => {
    setLoading(true);
    fetchData();

    intervalRef.current = setInterval(() => {
      const status = getMarketStatus();
      setMarketStatus(status);
      if (status.isOpen) {
        fetchData();
      }
    }, refreshIntervalMs);

    const statusCheck = setInterval(() => {
      setMarketStatus(getMarketStatus());
    }, 60000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      clearInterval(statusCheck);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, refreshIntervalMs]);

  const index = data
    ? {
        spotPrice: data.spotPrice,
        lastClose: data.lastClose,
        change: data.change,
        changePercent: data.changePercent,
        dayHigh: data.dayHigh,
        dayLow: data.dayLow,
        timestamp: Date.now(),
      }
    : null;

  return {
    symbol: config,
    index,
    optionChain: data?.data || [],
    expiryDates: data?.expiryDates || [],
    loading,
    error,
    lastUpdated,
    marketStatus,
    dataSource,
    priceHistory,
    refresh: fetchData,
  };
}
