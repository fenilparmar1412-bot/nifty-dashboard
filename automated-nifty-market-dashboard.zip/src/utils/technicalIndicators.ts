// ── Technical Indicators ──

// Generate synthetic price history for simulation
export function generatePriceHistory(basePrice: number, periods: number = 100, volatility: number = 0.015): number[] {
  const prices: number[] = [];
  let price = basePrice * 0.98;

  for (let i = 0; i < periods; i++) {
    const change = price * volatility * (Math.random() - 0.5) * 2;
    price = Math.max(price * 0.9, price + change);
    prices.push(Math.round(price * 100) / 100);
  }

  // Ensure last price is close to basePrice
  const adjustment = basePrice - prices[prices.length - 1];
  return prices.map((p, i) => {
    const factor = i / periods;
    return Math.round((p + adjustment * factor) * 100) / 100;
  });
}

// RSI (Relative Strength Index) — Wilder's smoothing
export function calculateRSI(prices: number[], period: number = 14): number[] {
  if (prices.length < period + 1) return [];

  const rsiValues: number[] = [];
  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? Math.abs(diff) : 0);
  }

  // First average
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  // First RSI
  const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  rsiValues.push(100 - (100 / (1 + rs)));

  // Subsequent values using Wilder's smoothing
  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
    const rsNow = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsiValues.push(100 - (100 / (1 + rsNow)));
  }

  return rsiValues;
}

// Simple Moving Average
export function calculateSMA(prices: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = period - 1; i < prices.length; i++) {
    const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    sma.push(sum / period);
  }
  return sma;
}

// Exponential Moving Average
export function calculateEMA(prices: number[], period: number): number[] {
  if (prices.length < period) return [];

  const k = 2 / (period + 1);
  const ema: number[] = [];

  // First EMA is SMA
  let emaPrev = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  ema.push(emaPrev);

  for (let i = period; i < prices.length; i++) {
    const emaNow = prices[i] * k + emaPrev * (1 - k);
    ema.push(emaNow);
    emaPrev = emaNow;
  }

  return ema;
}

// Bollinger Bands
export function calculateBollingerBands(prices: number[], period: number = 20, multiplier: number = 2) {
  const sma = calculateSMA(prices, period);
  const bands: { upper: number; middle: number; lower: number }[] = [];

  for (let i = period - 1; i < prices.length; i++) {
    const slice = prices.slice(i - period + 1, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / period;
    const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
    const stdDev = Math.sqrt(variance);

    bands.push({
      upper: sma[i - period + 1] + multiplier * stdDev,
      middle: sma[i - period + 1],
      lower: sma[i - period + 1] - multiplier * stdDev,
    });
  }

  return bands;
}

// ATR (Average True Range)
export function calculateATR(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 0;
  let atrSum = 0;

  for (let i = 1; i <= period; i++) {
    const tr = Math.abs(prices[i] - prices[i - 1]);
    atrSum += tr;
  }

  return atrSum / period;
}

// MACD
export function calculateMACD(prices: number[]) {
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);

  // Align the arrays
  const offset = ema12.length - ema26.length;
  const macdLine = ema26.map((val, i) => ema12[i + offset] - val);
  const signalLine = calculateEMA(macdLine, 9);

  return {
    macd: macdLine[macdLine.length - 1] || 0,
    signal: signalLine[signalLine.length - 1] || 0,
    histogram: (macdLine[macdLine.length - 1] || 0) - (signalLine[signalLine.length - 1] || 0),
  };
}

// RSI interpretation helper
export function interpretRSI(rsi: number): {
  signal: 'OVERBOUGHT' | 'NEUTRAL' | 'OVERSOLD';
  color: string;
  bgColor: string;
  message: string;
} {
  if (rsi >= 70) {
    return {
      signal: 'OVERBOUGHT',
      color: 'text-red-400',
      bgColor: 'bg-red-500/15',
      message: 'Strong — Possible reversal down',
    };
  } else if (rsi <= 30) {
    return {
      signal: 'OVERSOLD',
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/15',
      message: 'Weak — Possible reversal up',
    };
  } else if (rsi >= 60) {
    return {
      signal: 'NEUTRAL',
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/15',
      message: 'Bullish momentum',
    };
  } else if (rsi <= 40) {
    return {
      signal: 'NEUTRAL',
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/15',
      message: 'Bearish momentum',
    };
  }
  return {
    signal: 'NEUTRAL',
    color: 'text-slate-400',
    bgColor: 'bg-slate-700/30',
    message: 'Range-bound / Sideways',
  };
}

// PCR (Put-Call Ratio) based on OI
export function calculatePCR(optionChain: { ce: { openInterest: number }; pe: { openInterest: number } }[]): number {
  let totalCallOI = 0;
  let totalPutOI = 0;

  optionChain.forEach(row => {
    totalCallOI += row.ce.openInterest;
    totalPutOI += row.pe.openInterest;
  });

  if (totalCallOI === 0) return 1;
  return totalPutOI / totalCallOI;
}

// PCR Interpretation
export function interpretPCR(pcr: number): { signal: string; color: string; message: string } {
  if (pcr >= 1.3) {
    return { signal: 'BULLISH', color: 'text-emerald-400', message: 'Heavy put writing — Market may go UP' };
  } else if (pcr >= 1.0) {
    return { signal: 'MILDLY BULLISH', color: 'text-emerald-300', message: 'Slightly bullish bias' };
  } else if (pcr >= 0.7) {
    return { signal: 'NEUTRAL', color: 'text-amber-400', message: 'Balanced market' };
  } else if (pcr >= 0.5) {
    return { signal: 'MILDLY BEARISH', color: 'text-orange-400', message: 'Slightly bearish bias' };
  } else {
    return { signal: 'BEARISH', color: 'text-red-400', message: 'Heavy call writing — Market may go DOWN' };
  }
}

// Max Pain calculation — strike where option writers lose minimum
export function calculateMaxPain(optionChain: { strikePrice: number; ce: { openInterest: number }; pe: { openInterest: number } }[]): number {
  if (optionChain.length === 0) return 0;

  let minPain = Infinity;
  let maxPainStrike = optionChain[0].strikePrice;

  optionChain.forEach(testStrike => {
    let totalPain = 0;

    optionChain.forEach(row => {
      // CE writers' pain (if spot goes above strike at expiry)
      const cePain = Math.max(0, testStrike.strikePrice - row.strikePrice) * row.ce.openInterest;
      // PE writers' pain (if spot goes below strike at expiry)
      const pePain = Math.max(0, row.strikePrice - testStrike.strikePrice) * row.pe.openInterest;
      totalPain += cePain + pePain;
    });

    if (totalPain < minPain) {
      minPain = totalPain;
      maxPainStrike = testStrike.strikePrice;
    }
  });

  return maxPainStrike;
}
