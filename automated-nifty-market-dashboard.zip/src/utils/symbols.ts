// ── Tradable Symbols Registry ──

export type SymbolType = 'INDEX' | 'STOCK';

export interface SymbolConfig {
  symbol: string;
  displayName: string;
  type: SymbolType;
  lotSize: number;
  strikeStride: number; // gap between strikes
  basePrice: number; // approximate current price
  sector?: string;
  avgIV: number; // average implied volatility
  nseApiSymbol?: string;
}

// Index Options
export const INDICES: SymbolConfig[] = [
  {
    symbol: 'NIFTY',
    displayName: 'NIFTY 50',
    type: 'INDEX',
    lotSize: 25, // Post-Aug 2024
    strikeStride: 50,
    basePrice: 23200,
    sector: 'Benchmark',
    avgIV: 14,
    nseApiSymbol: 'NIFTY',
  },
  {
    symbol: 'BANKNIFTY',
    displayName: 'BANK NIFTY',
    type: 'INDEX',
    lotSize: 15,
    strikeStride: 100,
    basePrice: 49500,
    sector: 'Banking',
    avgIV: 16,
    nseApiSymbol: 'BANKNIFTY',
  },
  {
    symbol: 'FINNIFTY',
    displayName: 'FIN NIFTY',
    type: 'INDEX',
    lotSize: 40,
    strikeStride: 50,
    basePrice: 22800,
    sector: 'Financial Services',
    avgIV: 15,
    nseApiSymbol: 'FINNIFTY',
  },
  {
    symbol: 'MIDCPNIFTY',
    displayName: 'MIDCAP NIFTY',
    type: 'INDEX',
    lotSize: 50,
    strikeStride: 50,
    basePrice: 11500,
    sector: 'Mid Cap',
    avgIV: 18,
    nseApiSymbol: 'MIDCPNIFTY',
  },
  {
    symbol: 'SENSEX',
    displayName: 'SENSEX',
    type: 'INDEX',
    lotSize: 10,
    strikeStride: 100,
    basePrice: 76800,
    sector: 'Benchmark',
    avgIV: 13,
    nseApiSymbol: 'SENSEX',
  },
];

// Highly liquid Stock Options (Top traded on NSE)
export const STOCKS: SymbolConfig[] = [
  { symbol: 'RELIANCE', displayName: 'Reliance', type: 'STOCK', lotSize: 250, strikeStride: 20, basePrice: 2850, sector: 'Oil & Gas', avgIV: 22 },
  { symbol: 'HDFCBANK', displayName: 'HDFC Bank', type: 'STOCK', lotSize: 550, strikeStride: 20, basePrice: 1680, sector: 'Banking', avgIV: 20 },
  { symbol: 'ICICIBANK', displayName: 'ICICI Bank', type: 'STOCK', lotSize: 700, strikeStride: 10, basePrice: 1230, sector: 'Banking', avgIV: 21 },
  { symbol: 'TCS', displayName: 'TCS', type: 'STOCK', lotSize: 175, strikeStride: 40, basePrice: 4100, sector: 'IT', avgIV: 23 },
  { symbol: 'INFY', displayName: 'Infosys', type: 'STOCK', lotSize: 400, strikeStride: 20, basePrice: 1870, sector: 'IT', avgIV: 24 },
  { symbol: 'SBIN', displayName: 'SBI', type: 'STOCK', lotSize: 750, strikeStride: 10, basePrice: 780, sector: 'Banking', avgIV: 25 },
  { symbol: 'BHARTIARTL', displayName: 'Bharti Airtel', type: 'STOCK', lotSize: 475, strikeStride: 20, basePrice: 1680, sector: 'Telecom', avgIV: 22 },
  { symbol: 'ITC', displayName: 'ITC', type: 'STOCK', lotSize: 1600, strikeStride: 5, basePrice: 460, sector: 'FMCG', avgIV: 21 },
  { symbol: 'LT', displayName: 'L&T', type: 'STOCK', lotSize: 150, strikeStride: 40, basePrice: 3500, sector: 'Infra', avgIV: 24 },
  { symbol: 'AXISBANK', displayName: 'Axis Bank', type: 'STOCK', lotSize: 625, strikeStride: 20, basePrice: 1150, sector: 'Banking', avgIV: 23 },
  { symbol: 'KOTAKBANK', displayName: 'Kotak Bank', type: 'STOCK', lotSize: 400, strikeStride: 20, basePrice: 1820, sector: 'Banking', avgIV: 22 },
  { symbol: 'HINDUNILVR', displayName: 'HUL', type: 'STOCK', lotSize: 300, strikeStride: 40, basePrice: 2380, sector: 'FMCG', avgIV: 19 },
  { symbol: 'BAJFINANCE', displayName: 'Bajaj Finance', type: 'STOCK', lotSize: 125, strikeStride: 100, basePrice: 7200, sector: 'NBFC', avgIV: 26 },
  { symbol: 'TATAMOTORS', displayName: 'Tata Motors', type: 'STOCK', lotSize: 700, strikeStride: 10, basePrice: 740, sector: 'Auto', avgIV: 30 },
  { symbol: 'MARUTI', displayName: 'Maruti Suzuki', type: 'STOCK', lotSize: 100, strikeStride: 100, basePrice: 11500, sector: 'Auto', avgIV: 24 },
  { symbol: 'ADANIENT', displayName: 'Adani Enterprises', type: 'STOCK', lotSize: 300, strikeStride: 50, basePrice: 2850, sector: 'Conglomerate', avgIV: 38 },
  { symbol: 'WIPRO', displayName: 'Wipro', type: 'STOCK', lotSize: 1500, strikeStride: 5, basePrice: 580, sector: 'IT', avgIV: 25 },
  { symbol: 'HCLTECH', displayName: 'HCL Tech', type: 'STOCK', lotSize: 350, strikeStride: 40, basePrice: 1680, sector: 'IT', avgIV: 26 },
  { symbol: 'SUNPHARMA', displayName: 'Sun Pharma', type: 'STOCK', lotSize: 350, strikeStride: 20, basePrice: 1780, sector: 'Pharma', avgIV: 24 },
  { symbol: 'TATASTEEL', displayName: 'Tata Steel', type: 'STOCK', lotSize: 5500, strikeStride: 2, basePrice: 145, sector: 'Metals', avgIV: 32 },
];

export const ALL_SYMBOLS = [...INDICES, ...STOCKS];

export function getSymbolConfig(symbol: string): SymbolConfig {
  return ALL_SYMBOLS.find(s => s.symbol === symbol) || INDICES[0];
}
