// ── Black-Scholes & Greeks Calculator ──

import { Greeks } from '../types';

// Cumulative distribution function for standard normal distribution
function cdf(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x) / Math.sqrt(2.0);
  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return 0.5 * (1.0 + sign * y);
}

// Probability density function
function pdf(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

interface OptionInputs {
  spotPrice: number;
  strikePrice: number;
  timeToExpiry: number; // in years
  volatility: number; // e.g., 0.15 = 15%
  riskFreeRate: number; // e.g., 0.07 = 7%
  optionType: 'CE' | 'PE';
}

function calculateD1D2(inputs: OptionInputs) {
  const { spotPrice, strikePrice, timeToExpiry, volatility, riskFreeRate } = inputs;
  const sigmaSqrtT = volatility * Math.sqrt(timeToExpiry);
  const d1 = (Math.log(spotPrice / strikePrice) + (riskFreeRate + 0.5 * volatility * volatility) * timeToExpiry) / sigmaSqrtT;
  const d2 = d1 - sigmaSqrtT;
  return { d1, d2 };
}

export function calculateOptionPrice(inputs: OptionInputs): number {
  const { spotPrice, strikePrice, timeToExpiry, volatility, riskFreeRate, optionType } = inputs;
  if (timeToExpiry <= 0 || volatility <= 0) return 0;

  const { d1, d2 } = calculateD1D2(inputs);
  const discountFactor = Math.exp(-riskFreeRate * timeToExpiry);

  if (optionType === 'CE') {
    return spotPrice * cdf(d1) - strikePrice * discountFactor * cdf(d2);
  } else {
    return strikePrice * discountFactor * cdf(-d2) - spotPrice * cdf(-d1);
  }
}

export function calculateGreeks(inputs: OptionInputs): Greeks {
  const { spotPrice, strikePrice, timeToExpiry, volatility, riskFreeRate, optionType } = inputs;
  if (timeToExpiry <= 0 || volatility <= 0) {
    return { delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0 };
  }

  const { d1, d2 } = calculateD1D2(inputs);
  const discountFactor = Math.exp(-riskFreeRate * timeToExpiry);
  const sigmaSqrtT = volatility * Math.sqrt(timeToExpiry);
  const pdfD1 = pdf(d1);

  let delta: number;
  if (optionType === 'CE') {
    delta = cdf(d1);
  } else {
    delta = cdf(d1) - 1;
  }

  const gamma = pdfD1 / (spotPrice * sigmaSqrtT);
  const vega = (spotPrice * pdfD1 * Math.sqrt(timeToExpiry)) / 100;
  const theta = (-(spotPrice * pdfD1 * volatility) / (2 * Math.sqrt(timeToExpiry)) -
    (optionType === 'CE' ? 1 : -1) * riskFreeRate * strikePrice * discountFactor *
    (optionType === 'CE' ? cdf(d2) : cdf(-d2))) / 365;

  let rho: number;
  if (optionType === 'CE') {
    rho = (strikePrice * timeToExpiry * discountFactor * cdf(d2)) / 100;
  } else {
    rho = (-strikePrice * timeToExpiry * discountFactor * cdf(-d2)) / 100;
  }

  return { delta, gamma, theta, vega, rho };
}

export function calculateTotalStrategyGreeks(
  legs: { type: 'CE' | 'PE'; action: 'BUY' | 'SELL'; strikePrice: number }[],
  spotPrice: number,
  timeToExpiry: number,
  volatility: number,
  riskFreeRate: number
): Greeks {
  const totals: Greeks = { delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0 };

  legs.forEach((leg) => {
    const greeks = calculateGreeks({
      spotPrice,
      strikePrice: leg.strikePrice,
      timeToExpiry,
      volatility,
      riskFreeRate,
      optionType: leg.type,
    });
    const multiplier = leg.action === 'BUY' ? 1 : -1;
    totals.delta += greeks.delta * multiplier;
    totals.gamma += greeks.gamma * multiplier;
    totals.theta += greeks.theta * multiplier;
    totals.vega += greeks.vega * multiplier;
    totals.rho += greeks.rho * multiplier;
  });

  return totals;
}

export function calculatePayoff(
  legs: { type: 'CE' | 'PE'; action: 'BUY' | 'SELL'; strikePrice: number; premium: number; quantity: number }[],
  spotPrice: number
): number {
  let totalPnl = 0;

  legs.forEach((leg) => {
    const { type, action, strikePrice, premium, quantity } = leg;
    let intrinsicValue = 0;

    if (type === 'CE') {
      intrinsicValue = Math.max(0, spotPrice - strikePrice);
    } else {
      intrinsicValue = Math.max(0, strikePrice - spotPrice);
    }

    const pnl = (intrinsicValue - premium) * quantity * (action === 'BUY' ? 1 : -1);
    totalPnl += pnl;
  });

  return totalPnl;
}

export function generatePayoffCurve(
  legs: { type: 'CE' | 'PE'; action: 'BUY' | 'SELL'; strikePrice: number; premium: number; quantity: number }[],
  spotPrice: number,
  range = 0.15,
  points = 100
) {
  const minPrice = spotPrice * (1 - range);
  const maxPrice = spotPrice * (1 + range);
  const step = (maxPrice - minPrice) / points;

  const curve = [];
  for (let i = 0; i <= points; i++) {
    const price = minPrice + step * i;
    curve.push({
      spotPrice: Math.round(price * 100) / 100,
      pnl: Math.round(calculatePayoff(legs, price) * 100) / 100,
    });
  }

  return curve;
}

export function formatIndianNumber(num: number): string {
  if (Math.abs(num) >= 10000000) {
    return (num / 10000000).toFixed(2) + ' Cr';
  }
  if (Math.abs(num) >= 100000) {
    return (num / 100000).toFixed(2) + ' L';
  }
  if (Math.abs(num) >= 1000) {
    return (num / 1000).toFixed(2) + ' K';
  }
  return num.toFixed(2);
}

export function formatCurrency(num: number): string {
  return '₹' + num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
