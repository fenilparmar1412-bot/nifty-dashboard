// ── Market Hours Utility ──

export interface MarketStatus {
  isOpen: boolean;
  session: 'PRE-OPEN' | 'LIVE' | 'POST' | 'CLOSED' | 'WEEKEND' | 'HOLIDAY';
  label: string;
  color: string;
  nextOpen?: string;
}

export function getMarketStatus(now: Date = new Date()): MarketStatus {
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const totalMinutes = hours * 60 + minutes;
  const day = now.getDay(); // 0 = Sunday, 6 = Saturday

  // Weekend check
  if (day === 0) {
    return {
      isOpen: false,
      session: 'WEEKEND',
      label: 'Sunday — Market Closed',
      color: 'bg-slate-500',
      nextOpen: 'Monday 9:15 AM',
    };
  }
  if (day === 6) {
    return {
      isOpen: false,
      session: 'WEEKEND',
      label: 'Saturday — Market Closed',
      color: 'bg-slate-500',
      nextOpen: 'Monday 9:15 AM',
    };
  }

  // Pre-market: 9:00 - 9:07 (pre-open session)
  if (totalMinutes >= 540 && totalMinutes < 547) {
    return {
      isOpen: false,
      session: 'PRE-OPEN',
      label: 'Pre-Open Session (No trades)',
      color: 'bg-amber-500',
      nextOpen: '9:15 AM',
    };
  }

  // Pre-open to open gap: 9:07 - 9:15
  if (totalMinutes >= 547 && totalMinutes < 555) {
    return {
      isOpen: false,
      session: 'PRE-OPEN',
      label: 'Order Matching Phase',
      color: 'bg-amber-500',
      nextOpen: '9:15 AM',
    };
  }

  // Regular market: 9:15 - 15:30
  if (totalMinutes >= 555 && totalMinutes < 930) {
    return {
      isOpen: true,
      session: 'LIVE',
      label: 'Market Open — LIVE',
      color: 'bg-emerald-500',
    };
  }

  // Post-market: 15:30 - 16:00
  if (totalMinutes >= 930 && totalMinutes < 960) {
    return {
      isOpen: false,
      session: 'POST',
      label: 'Post-Market Session',
      color: 'bg-amber-500',
    };
  }

  // Before market (00:00 - 9:00)
  if (totalMinutes < 540) {
    return {
      isOpen: false,
      session: 'CLOSED',
      label: 'Market Closed — Pre-Open at 9:00 AM',
      color: 'bg-slate-500',
      nextOpen: '9:15 AM today',
    };
  }

  // After market (16:00 - 24:00)
  return {
    isOpen: false,
    session: 'CLOSED',
    label: 'Market Closed — See you tomorrow',
    color: 'bg-slate-500',
    nextOpen: day === 5 ? 'Monday 9:15 AM' : 'Tomorrow 9:15 AM',
  };
}

// Check if we should refresh data
export function shouldRefreshData(): boolean {
  const status = getMarketStatus();
  // Only refresh during market hours or pre-open (for pre-open data)
  return status.session === 'LIVE' || status.session === 'PRE-OPEN';
}
