// ── Strike Sentiment Analysis ──
// Analyzes each strike to determine bullish/bearish bias based on OI activity

import { OptionData } from '../types';

export interface StrikeSentiment {
  strikePrice: number;
  score: number; // -100 (very bearish) to +100 (very bullish)
  label: 'VERY_BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' | 'VERY_BEARISH';
  signal: string;
  reason: string[];
  supportStrength: number; // 0-100
  resistanceStrength: number; // 0-100
  color: string;
  bgColor: string;
  borderColor: string;
  icon: string;
  action: string;
}

/**
 * Calculate sentiment score for a single strike based on OI activity
 *
 * Bullish signals (positive score):
 *  - Put writing (PE OI ↑) = Support building
 *  - Call unwinding (CE OI ↓) = Resistance broken
 *  - High Put OI = Strong support
 *  - PE price rising with OI = Put buying (hedge/fear) — slight bearish
 *
 * Bearish signals (negative score):
 *  - Call writing (CE OI ↑) = Resistance building
 *  - Put unwinding (PE OI ↓) = Support broken
 *  - High Call OI = Strong resistance
 *  - CE price rising with OI = Call buying (bullish) — slight bullish
 */
export function calculateStrikeSentiment(
  row: OptionData,
  spotPrice: number,
  maxOI: number
): StrikeSentiment {
  const reasons: string[] = [];
  let score = 0;

  const ceOI = row.ce.openInterest;
  const peOI = row.pe.openInterest;
  const ceChangeOI = row.ce.changeInOI;
  const peChangeOI = row.pe.changeInOI;
  const cePriceChange = row.ce.change;
  const pePriceChange = row.pe.change;

  const oiRatio = ceOI > 0 && peOI > 0 ? ceOI / peOI : 1;

  // 1. Put Writing (Bullish) — PE OI increasing + PE price decreasing
  if (peChangeOI > 0 && pePriceChange <= 0) {
    const strength = Math.min(25, (peChangeOI / Math.max(1, peOI)) * 100);
    score += strength;
    reasons.push(`✍️ Put writing (+${formatOI(peChangeOI)})`);
  }

  // 2. Call Writing (Bearish) — CE OI increasing + CE price decreasing
  if (ceChangeOI > 0 && cePriceChange <= 0) {
    const strength = Math.min(25, (ceChangeOI / Math.max(1, ceOI)) * 100);
    score -= strength;
    reasons.push(`✍️ Call writing (+${formatOI(ceChangeOI)})`);
  }

  // 3. Call Unwinding (Bullish) — CE OI decreasing + CE price increasing
  if (ceChangeOI < 0 && cePriceChange > 0) {
    const strength = Math.min(20, (Math.abs(ceChangeOI) / Math.max(1, ceOI)) * 100);
    score += strength;
    reasons.push(`🚀 Call unwinding (${formatOI(ceChangeOI)})`);
  }

  // 4. Put Unwinding (Bearish) — PE OI decreasing + PE price increasing
  if (peChangeOI < 0 && pePriceChange > 0) {
    const strength = Math.min(20, (Math.abs(peChangeOI) / Math.max(1, peOI)) * 100);
    score -= strength;
    reasons.push(`📉 Put unwinding (${formatOI(peChangeOI)})`);
  }

  // 5. Long Buildup in Calls (Bullish) — CE OI ↑ + CE price ↑
  if (ceChangeOI > 0 && cePriceChange > 0) {
    const strength = Math.min(15, (ceChangeOI / Math.max(1, ceOI)) * 50);
    score += strength;
    reasons.push(`📈 Call long buildup`);
  }

  // 6. Long Buildup in Puts (Bearish) — PE OI ↑ + PE price ↑
  if (peChangeOI > 0 && pePriceChange > 0) {
    const strength = Math.min(15, (peChangeOI / Math.max(1, peOI)) * 50);
    score -= strength;
    reasons.push(`📉 Put long buildup`);
  }

  // 7. PCR at this strike
  if (oiRatio < 0.7) {
    score += 15;
    reasons.push(`🛡️ Strong support (PCR: ${(1/oiRatio).toFixed(2)})`);
  } else if (oiRatio > 1.5) {
    score -= 15;
    reasons.push(`🧱 Strong resistance (PCR: ${(1/oiRatio).toFixed(2)})`);
  }

  // 8. Strike position relative to spot
  const distFromSpot = (row.strikePrice - spotPrice) / spotPrice;
  if (distFromSpot < -0.02 && peOI > maxOI * 0.3) {
    score += 10;
    reasons.push(`💪 Below-spot put wall`);
  } else if (distFromSpot > 0.02 && ceOI > maxOI * 0.3) {
    score -= 10;
    reasons.push(`🧱 Above-spot call wall`);
  }

  // Normalize score to -100 to +100
  score = Math.max(-100, Math.min(100, score));

  // Calculate support and resistance strength
  const supportStrength = Math.min(100, (peOI / maxOI) * 100 + Math.max(0, score));
  const resistanceStrength = Math.min(100, (ceOI / maxOI) * 100 + Math.max(0, -score));

  // Determine label and appearance
  let label: StrikeSentiment['label'];
  let color: string;
  let bgColor: string;
  let borderColor: string;
  let icon: string;
  let signal: string;
  let action: string;

  if (score >= 40) {
    label = 'VERY_BULLISH';
    color = 'text-emerald-400';
    bgColor = 'bg-emerald-500/15';
    borderColor = 'border-emerald-500/40';
    icon = '🚀';
    signal = 'STRONG BULLISH';
    action = 'Buy CE / Sell PE';
  } else if (score >= 15) {
    label = 'BULLISH';
    color = 'text-emerald-300';
    bgColor = 'bg-emerald-500/10';
    borderColor = 'border-emerald-500/25';
    icon = '📈';
    signal = 'BULLISH';
    action = 'Prefer CE side';
  } else if (score <= -40) {
    label = 'VERY_BEARISH';
    color = 'text-red-400';
    bgColor = 'bg-red-500/15';
    borderColor = 'border-red-500/40';
    icon = '🔻';
    signal = 'STRONG BEARISH';
    action = 'Buy PE / Sell CE';
  } else if (score <= -15) {
    label = 'BEARISH';
    color = 'text-red-300';
    bgColor = 'bg-red-500/10';
    borderColor = 'border-red-500/25';
    icon = '📉';
    signal = 'BEARISH';
    action = 'Prefer PE side';
  } else {
    label = 'NEUTRAL';
    color = 'text-slate-400';
    bgColor = 'bg-slate-700/20';
    borderColor = 'border-slate-700/50';
    icon = '⚖️';
    signal = 'NEUTRAL';
    action = 'Wait / Both sides';
  }

  if (reasons.length === 0) {
    reasons.push('No clear signal');
  }

  return {
    strikePrice: row.strikePrice,
    score,
    label,
    signal,
    reason: reasons.slice(0, 3), // Top 3 reasons
    supportStrength,
    resistanceStrength,
    color,
    bgColor,
    borderColor,
    icon,
    action,
  };
}

/**
 * Analyze entire option chain and return sorted by sentiment
 */
export function analyzeChainSentiment(
  optionChain: OptionData[],
  spotPrice: number
): StrikeSentiment[] {
  const maxOI = Math.max(
    ...optionChain.map(r => Math.max(r.ce.openInterest, r.pe.openInterest)),
    1
  );

  return optionChain
    .map(row => calculateStrikeSentiment(row, spotPrice, maxOI))
    .sort((a, b) => Math.abs(b.score) - Math.abs(a.score));
}

/**
 * Get overall market sentiment from option chain
 */
export function getMarketSentiment(optionChain: OptionData[], spotPrice: number): {
  overallScore: number;
  label: string;
  color: string;
  bullishStrikes: number;
  bearishStrikes: number;
  neutralStrikes: number;
  topBullish: StrikeSentiment[];
  topBearish: StrikeSentiment[];
  supportLevels: number[];
  resistanceLevels: number[];
} {
  const sentiments = analyzeChainSentiment(optionChain, spotPrice);

  let totalScore = 0;
  let bullishStrikes = 0;
  let bearishStrikes = 0;
  let neutralStrikes = 0;

  sentiments.forEach(s => {
    totalScore += s.score;
    if (s.score >= 15) bullishStrikes++;
    else if (s.score <= -15) bearishStrikes++;
    else neutralStrikes++;
  });

  const avgScore = sentiments.length > 0 ? totalScore / sentiments.length : 0;

  // Top bullish/bearish strikes
  const topBullish = sentiments
    .filter(s => s.score >= 20)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  const topBearish = sentiments
    .filter(s => s.score <= -20)
    .sort((a, b) => a.score - b.score)
    .slice(0, 5);

  // Support levels (high put OI below spot)
  const supportLevels = optionChain
    .filter(r => r.strikePrice < spotPrice)
    .sort((a, b) => b.pe.openInterest - a.pe.openInterest)
    .slice(0, 3)
    .map(r => r.strikePrice);

  // Resistance levels (high call OI above spot)
  const resistanceLevels = optionChain
    .filter(r => r.strikePrice > spotPrice)
    .sort((a, b) => b.ce.openInterest - a.ce.openInterest)
    .slice(0, 3)
    .map(r => r.strikePrice);

  let label: string;
  let color: string;

  if (avgScore >= 20) {
    label = 'BULLISH MARKET';
    color = 'text-emerald-400';
  } else if (avgScore >= 5) {
    label = 'MILDLY BULLISH';
    color = 'text-emerald-300';
  } else if (avgScore <= -20) {
    label = 'BEARISH MARKET';
    color = 'text-red-400';
  } else if (avgScore <= -5) {
    label = 'MILDLY BEARISH';
    color = 'text-red-300';
  } else {
    label = 'NEUTRAL MARKET';
    color = 'text-amber-400';
  }

  return {
    overallScore: avgScore,
    label,
    color,
    bullishStrikes,
    bearishStrikes,
    neutralStrikes,
    topBullish,
    topBearish,
    supportLevels,
    resistanceLevels,
  };
}

function formatOI(oi: number): string {
  const abs = Math.abs(oi);
  if (abs >= 10000000) return (abs / 10000000).toFixed(1) + 'Cr';
  if (abs >= 100000) return (abs / 100000).toFixed(1) + 'L';
  if (abs >= 1000) return (abs / 1000).toFixed(1) + 'K';
  return abs.toFixed(0);
}
