// ── Advanced Option Trading Formulas ──

import { calculateOptionPrice } from './optionCalculations';

// ═══════════════════════════════════════════════════════════════
// 1. IMPLIED VOLATILITY (Newton-Raphson method)
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate Implied Volatility from market price
 * Uses Newton-Raphson iteration to reverse engineer IV
 */
export function calculateImpliedVolatility(
  marketPrice: number,
  spotPrice: number,
  strikePrice: number,
  timeToExpiry: number,
  riskFreeRate: number,
  optionType: 'CE' | 'PE'
): number {
  if (marketPrice <= 0 || timeToExpiry <= 0) return 0;

  let iv = 0.5; // Initial guess: 50% IV
  const tolerance = 0.0001;
  const maxIterations = 100;

  for (let i = 0; i < maxIterations; i++) {
    const price = calculateOptionPrice({
      spotPrice,
      strikePrice,
      timeToExpiry,
      volatility: iv,
      riskFreeRate,
      optionType,
    });

    const diff = price - marketPrice;

    if (Math.abs(diff) < tolerance) {
      return iv * 100; // Return as percentage
    }

    // Vega = dP/dIV (derivative of price w.r.t IV)
    const vega = calculateVegaNumerical(spotPrice, strikePrice, timeToExpiry, iv, riskFreeRate, optionType);

    if (Math.abs(vega) < 0.0001) break;

    // Newton-Raphson update
    iv = iv - diff / vega;

    // Keep IV in reasonable bounds
    if (iv < 0.01) iv = 0.01;
    if (iv > 5) iv = 5;
  }

  return iv * 100;
}

function calculateVegaNumerical(
  spotPrice: number,
  strikePrice: number,
  timeToExpiry: number,
  iv: number,
  riskFreeRate: number,
  optionType: 'CE' | 'PE'
): number {
  const delta = 0.0001;
  const priceUp = calculateOptionPrice({
    spotPrice, strikePrice, timeToExpiry,
    volatility: iv + delta, riskFreeRate, optionType,
  });
  const priceDown = calculateOptionPrice({
    spotPrice, strikePrice, timeToExpiry,
    volatility: iv - delta, riskFreeRate, optionType,
  });
  return (priceUp - priceDown) / (2 * delta);
}

// ═══════════════════════════════════════════════════════════════
// 2. IV RANK & IV PERCENTILE
// ═══════════════════════════════════════════════════════════════

/**
 * IV Rank = (Current IV - 52w Low IV) / (52w High IV - 52w Low IV)
 * Tells you where current IV stands in the range
 */
export function calculateIVRank(currentIV: number, iv52wLow: number, iv52wHigh: number): number {
  if (iv52wHigh === iv52wLow) return 50;
  return Math.max(0, Math.min(100, ((currentIV - iv52wLow) / (iv52wHigh - iv52wLow)) * 100));
}

/**
 * IV Percentile = % of days in past year when IV was lower than current
 * More accurate than IV Rank for trading decisions
 */
export function calculateIVPercentile(currentIV: number, historicalIVs: number[]): number {
  if (historicalIVs.length === 0) return 50;
  const lowerCount = historicalIVs.filter(iv => iv < currentIV).length;
  return (lowerCount / historicalIVs.length) * 100;
}

/**
 * Interpret IV Rank/Percentile for trading
 */
export function interpretIV(ivRank: number): {
  signal: string;
  color: string;
  strategy: string;
  message: string;
} {
  if (ivRank >= 80) {
    return {
      signal: 'VERY HIGH',
      color: 'text-red-400',
      strategy: 'SELL Options (Iron Condor, Short Strangle)',
      message: 'Premiums are expensive — great for sellers',
    };
  } else if (ivRank >= 60) {
    return {
      signal: 'HIGH',
      color: 'text-orange-400',
      strategy: 'Consider Selling (Credit Spreads)',
      message: 'Premiums above average — selling favored',
    };
  } else if (ivRank >= 40) {
    return {
      signal: 'NORMAL',
      color: 'text-amber-400',
      strategy: 'Neutral — Any strategy',
      message: 'IV in normal range — use directional view',
    };
  } else if (ivRank >= 20) {
    return {
      signal: 'LOW',
      color: 'text-cyan-400',
      strategy: 'Consider Buying (Long Straddle, Debit Spreads)',
      message: 'Premiums below average — buying favored',
    };
  } else {
    return {
      signal: 'VERY LOW',
      color: 'text-emerald-400',
      strategy: 'BUY Options (Long Straddle, Long Strangle)',
      message: 'Premiums are cheap — great for buyers',
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// 3. PROBABILITY OF PROFIT (POP)
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate Probability of Profit using normal distribution
 * For a simple option trade
 */
export function calculatePOP(
  spotPrice: number,
  strikePrice: number,
  premium: number,
  timeToExpiry: number,
  iv: number,
  optionType: 'CE' | 'PE',
  action: 'BUY' | 'SELL'
): number {
  // Standard deviation of price over time period
  const stdDev = spotPrice * (iv / 100) * Math.sqrt(timeToExpiry);

  // Break-even point
  let breakEven: number;
  if (optionType === 'CE') {
    breakEven = action === 'BUY'
      ? strikePrice + premium
      : strikePrice - premium;
  } else {
    breakEven = action === 'BUY'
      ? strikePrice - premium
      : strikePrice + premium;
  }

  // Z-score
  const z = (breakEven - spotPrice) / stdDev;

  // Probability using CDF
  const prob = normalCDF(optionType === 'CE' ? -z : z);

  // For buyers: need to be ITM past break-even
  // For sellers: need to stay OTM past break-even
  return action === 'BUY' ? (1 - prob) * 100 : prob * 100;
}

/**
 * Standard normal CDF (cumulative distribution function)
 */
function normalCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);
  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

// ═══════════════════════════════════════════════════════════════
// 4. EXPECTED MOVE (1σ, 2σ, 3σ)
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate expected price range based on volatility
 * 1σ = 68% probability, 2σ = 95%, 3σ = 99.7%
 */
export function calculateExpectedMove(
  spotPrice: number,
  iv: number,
  daysToExpiry: number
): {
  sigma1: { up: number; down: number; range: number };
  sigma2: { up: number; down: number; range: number };
  sigma3: { up: number; down: number; range: number };
  dailyMove: number;
} {
  const timeFactor = Math.sqrt(daysToExpiry / 365);
  const ivFactor = iv / 100;

  const move1 = spotPrice * ivFactor * timeFactor;
  const move2 = move1 * 2;
  const move3 = move1 * 3;

  // Daily expected move (sqrt of 1 day)
  const dailyMove = spotPrice * ivFactor / Math.sqrt(365);

  return {
    sigma1: {
      up: spotPrice + move1,
      down: spotPrice - move1,
      range: move1,
    },
    sigma2: {
      up: spotPrice + move2,
      down: spotPrice - move2,
      range: move2,
    },
    sigma3: {
      up: spotPrice + move3,
      down: spotPrice - move3,
      range: move3,
    },
    dailyMove,
  };
}

/**
 * Market-implied expected move from ATM straddle price
 * Most accurate method used by pros
 */
export function calculateImpliedMoveFromStraddle(
  atmCallPrice: number,
  atmPutPrice: number,
  spotPrice: number
): number {
  const straddlePrice = atmCallPrice + atmPutPrice;
  return (straddlePrice / spotPrice) * 100; // Returns as percentage
}

// ═══════════════════════════════════════════════════════════════
// 5. THETA DECAY PROJECTION
// ═══════════════════════════════════════════════════════════════

/**
 * Project option price decay over coming days
 */
export function projectThetaDecay(
  spotPrice: number,
  strikePrice: number,
  currentIV: number,
  daysToExpiry: number,
  riskFreeRate: number,
  optionType: 'CE' | 'PE'
): { day: number; price: number; theta: number }[] {
  const projections: { day: number; price: number; theta: number }[] = [];
  const daysToShow = Math.min(daysToExpiry, 30);

  for (let d = 0; d <= daysToShow; d++) {
    const timeLeft = (daysToExpiry - d) / 365;
    if (timeLeft <= 0) break;

    const price = calculateOptionPrice({
      spotPrice,
      strikePrice,
      timeToExpiry: timeLeft,
      volatility: currentIV / 100,
      riskFreeRate,
      optionType,
    });

    const priceNext = d < daysToExpiry ? calculateOptionPrice({
      spotPrice,
      strikePrice,
      timeToExpiry: (daysToExpiry - d - 1) / 365,
      volatility: currentIV / 100,
      riskFreeRate,
      optionType,
    }) : 0;

    projections.push({
      day: d,
      price: Math.round(price * 100) / 100,
      theta: Math.round((price - priceNext) * 100) / 100,
    });
  }

  return projections;
}

// ═══════════════════════════════════════════════════════════════
// 6. RISK/REWARD RATIO
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate Risk/Reward ratio for a strategy
 */
export function calculateRiskReward(maxProfit: number, maxLoss: number): {
  ratio: number;
  rating: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR';
  color: string;
  message: string;
} {
  const absLoss = Math.abs(maxLoss);
  if (absLoss === 0) {
    return { ratio: 999, rating: 'EXCELLENT', color: 'text-emerald-400', message: 'No risk — free trade!' };
  }

  const ratio = maxProfit / absLoss;

  if (ratio >= 3) {
    return { ratio, rating: 'EXCELLENT', color: 'text-emerald-400', message: 'High reward for small risk' };
  } else if (ratio >= 2) {
    return { ratio, rating: 'GOOD', color: 'text-cyan-400', message: 'Favorable risk-reward' };
  } else if (ratio >= 1) {
    return { ratio, rating: 'FAIR', color: 'text-amber-400', message: 'Balanced risk-reward' };
  } else {
    return { ratio, rating: 'POOR', color: 'text-red-400', message: 'High risk for low reward' };
  }
}

// ═══════════════════════════════════════════════════════════════
// 7. POSITION SIZING (Kelly Criterion & Fixed Risk)
// ═══════════════════════════════════════════════════════════════

/**
 * Kelly Criterion - optimal position size
 */
export function calculateKellyPosition(
  winRate: number,
  avgWin: number,
  avgLoss: number,
  capital: number
): {
  kellyPct: number;
  halfKellyPct: number;
  amountToRisk: number;
  message: string;
} {
  if (avgLoss === 0) {
    return { kellyPct: 0, halfKellyPct: 0, amountToRisk: 0, message: 'Cannot calculate — no losses' };
  }

  const winProb = winRate / 100;
  const lossProb = 1 - winProb;
  const winLossRatio = avgWin / avgLoss;

  // Kelly formula: f = (bp - q) / b
  const kelly = ((winLossRatio * winProb) - lossProb) / winLossRatio;
  const kellyPct = Math.max(0, Math.min(1, kelly)) * 100;

  // Half Kelly is safer (most traders use this)
  const halfKellyPct = kellyPct / 2;

  const amountToRisk = (capital * halfKellyPct) / 100;

  let message = '';
  if (kellyPct === 0) {
    message = 'No edge detected — do not trade';
  } else if (kellyPct < 5) {
    message = 'Small edge — use 1-2% capital';
  } else if (kellyPct < 15) {
    message = 'Moderate edge — Half Kelly recommended';
  } else {
    message = 'Strong edge — but cap at 10% capital';
  }

  return { kellyPct, halfKellyPct, amountToRisk, message };
}

/**
 * Fixed Risk Position Sizing (2% rule)
 */
export function calculateFixedRiskPosition(
  capital: number,
  riskPerTrade: number, // as percentage (e.g., 2)
  maxLossPerLot: number
): {
  lots: number;
  totalCapital: number;
  riskAmount: number;
} {
  const riskAmount = (capital * riskPerTrade) / 100;
  const lots = maxLossPerLot > 0 ? Math.floor(riskAmount / maxLossPerLot) : 0;
  const totalCapital = lots * maxLossPerLot;

  return { lots, totalCapital, riskAmount };
}

// ═══════════════════════════════════════════════════════════════
// 8. IV SKEW ANALYSIS
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate IV Skew between OTM Put and OTM Call
 * Positive skew = Puts more expensive (fear in market)
 */
export function calculateIVSkew(
  atmIV: number,
  otmPutIV: number,
  otmCallIV: number
): {
  skew: number;
  putSkew: number;
  callSkew: number;
  interpretation: string;
  signal: string;
  color: string;
} {
  const putSkew = otmPutIV - atmIV;
  const callSkew = otmCallIV - atmIV;
  const skew = otmPutIV - otmCallIV;

  let interpretation = '';
  let signal = '';
  let color = '';

  if (skew > 5) {
    interpretation = 'Heavy Put Skew — Market fearful, expecting downside';
    signal = 'BEARISH BIAS';
    color = 'text-red-400';
  } else if (skew > 2) {
    interpretation = 'Moderate Put Skew — Normal fear premium';
    signal = 'MILDLY BEARISH';
    color = 'text-orange-400';
  } else if (skew >= -2) {
    interpretation = 'Neutral Skew — Balanced market';
    signal = 'NEUTRAL';
    color = 'text-slate-400';
  } else if (skew >= -5) {
    interpretation = 'Call Skew — Greed in market, expecting upside';
    signal = 'MILDLY BULLISH';
    color = 'text-cyan-400';
  } else {
    interpretation = 'Heavy Call Skew — Extreme bullish sentiment';
    signal = 'BULLISH BIAS';
    color = 'text-emerald-400';
  }

  return { skew, putSkew, callSkew, interpretation, signal, color };
}

// ═══════════════════════════════════════════════════════════════
// 9. DELTA NEUTRAL BALANCER
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate how many shares/options needed to make portfolio delta neutral
 */
export function calculateDeltaHedge(
  portfolioDelta: number,
  optionDelta: number,
  lotSize: number
): {
  lotsToBuy: number;
  lotsToSell: number;
  sharesToBuy: number;
  sharesToSell: number;
  message: string;
} {
  // Shares needed
  const sharesToBalance = -portfolioDelta;
  const sharesToBuy = sharesToBalance > 0 ? Math.round(sharesToBalance) : 0;
  const sharesToSell = sharesToBalance < 0 ? Math.round(Math.abs(sharesToBalance)) : 0;

  // Option lots needed
  const lotsNeeded = optionDelta !== 0 ? -portfolioDelta / (optionDelta * lotSize) : 0;
  const lotsToBuy = lotsNeeded > 0 ? Math.ceil(lotsNeeded) : 0;
  const lotsToSell = lotsNeeded < 0 ? Math.ceil(Math.abs(lotsNeeded)) : 0;

  let message = '';
  if (Math.abs(portfolioDelta) < 0.1) {
    message = '✅ Portfolio is delta neutral';
  } else if (portfolioDelta > 0) {
    message = `Portfolio is LONG delta — Sell ${Math.abs(portfolioDelta).toFixed(2)} delta to neutralize`;
  } else {
    message = `Portfolio is SHORT delta — Buy ${Math.abs(portfolioDelta).toFixed(2)} delta to neutralize`;
  }

  return { lotsToBuy, lotsToSell, sharesToBuy, sharesToSell, message };
}

// ═══════════════════════════════════════════════════════════════
// 10. STRADDLE PRICING & BREAKEVEN
// ═══════════════════════════════════════════════════════════════

/**
 * Calculate straddle/strangle break-evens
 */
export function calculateStraddleBreakeven(
  strikePrice: number,
  callPremium: number,
  putPremium: number
): {
  totalPremium: number;
  upperBreakeven: number;
  lowerBreakeven: number;
  moveNeeded: number;
  movePercent: number;
} {
  const totalPremium = callPremium + putPremium;
  return {
    totalPremium,
    upperBreakeven: strikePrice + totalPremium,
    lowerBreakeven: strikePrice - totalPremium,
    moveNeeded: totalPremium,
    movePercent: (totalPremium / strikePrice) * 100,
  };
}

// ═══════════════════════════════════════════════════════════════
// 11. PROBABILITY ITM / OTM
// ═══════════════════════════════════════════════════════════════

/**
 * Probability of option expiring ITM
 */
export function calculateProbabilityITM(
  spotPrice: number,
  strikePrice: number,
  timeToExpiry: number,
  iv: number,
  optionType: 'CE' | 'PE'
): number {
  const ivFactor = iv / 100;
  const timeFactor = Math.sqrt(Math.max(0.0001, timeToExpiry));
  const d2 = (Math.log(spotPrice / strikePrice) + (0.07 - 0.5 * ivFactor * ivFactor) * timeToExpiry) /
    (ivFactor * timeFactor);

  if (optionType === 'CE') {
    return normalCDF(d2) * 100;
  } else {
    return normalCDF(-d2) * 100;
  }
}

// ═══════════════════════════════════════════════════════════════
// 12. SHARPE RATIO (Risk-adjusted return)
// ═══════════════════════════════════════════════════════════════

export function calculateSharpeRatio(
  returns: number[],
  riskFreeRate: number = 7
): {
  sharpe: number;
  rating: string;
  color: string;
} {
  if (returns.length < 2) {
    return { sharpe: 0, rating: 'N/A', color: 'text-slate-400' };
  }

  const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);

  if (stdDev === 0) {
    return { sharpe: 0, rating: 'N/A', color: 'text-slate-400' };
  }

  const sharpe = (avgReturn - riskFreeRate / 100) / stdDev;

  let rating = '';
  let color = '';
  if (sharpe >= 2) {
    rating = 'Excellent';
    color = 'text-emerald-400';
  } else if (sharpe >= 1) {
    rating = 'Good';
    color = 'text-cyan-400';
  } else if (sharpe >= 0.5) {
    rating = 'Average';
    color = 'text-amber-400';
  } else if (sharpe >= 0) {
    rating = 'Poor';
    color = 'text-orange-400';
  } else {
    rating = 'Negative';
    color = 'text-red-400';
  }

  return { sharpe, rating, color };
}
